const fs = require('node:fs');
const path = require('node:path');
const { zipSync } = require('fflate');
const root = path.resolve(__dirname, '..');
const version = require('../package.json').version;
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
const zip = path.join(root, 'dist', `ForeverLogger-${version}.zip`);
const entries = {};
function add(destination, source = destination) {
  entries[destination] = fs.readFileSync(path.join(root, source));
}
// Explicit ownership allowlist: concurrent components may share the workspace root.
add('ForeverLogger/ForeverLogger.toc');
const toc = entries['ForeverLogger/ForeverLogger.toc'].toString('utf8');
if (!toc.includes(`## Version: ${version}`)) throw Error('TOC/package version mismatch');
for (const module of toc.split(/\r?\n/).map(s => s.trim()).filter(s => s.endsWith('.lua'))) {
  if (module.includes('..') || path.isAbsolute(module)) throw Error('Invalid TOC module path');
  add(`ForeverLogger/${module}`);
}
const component = fs.existsSync(path.join(root, 'addon/docs/INTEGRATION.md')) ? 'addon/' : '';
add('README.md', component + 'README.md');
for (const name of ['API_RESEARCH.md', 'SCHEMA.md', 'LIMITATIONS.md', 'VALIDATION.md', 'INTEGRATION.md']) add('docs/' + name, component + 'docs/' + name);
for (const name of ['run.cjs', 'wow_mock.lua', 'addon.test.lua', 'export.test.cjs']) add('tests/' + name);
for (const name of ['export.cjs', 'package.cjs']) add('tools/' + name);
for (const name of ['LICENSE', 'package.json', 'package-lock.json']) add(name);
fs.writeFileSync(zip, zipSync(entries, { level: 9 }));
console.log(zip);
