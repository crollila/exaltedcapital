#!/usr/bin/env node
'use strict';
// Parse a restricted Lua data grammar. Never execute SavedVariables as code.
const fs = require('node:fs');
const { once } = require('node:events');
const luaparse = require('luaparse');
function parseSavedVariables(input) {
  const bytes = Buffer.isBuffer(input) ? input : Buffer.from(input, 'utf8');
  const source = bytes.toString('latin1').replace(/^\xef\xbb\xbf/, '');
  const ast = luaparse.parse(source, { luaVersion: '5.1', encodingMode: 'pseudo-latin1', comments: false });
  function decode(node, depth = 0) {
    if (depth > 64) throw Error('Data exceeds maximum nesting depth');
    switch (node.type) {
      case 'StringLiteral': return Buffer.from(node.value, 'latin1').toString('utf8');
      case 'NumericLiteral':
        if (!Number.isFinite(node.value)) throw Error('Non-finite number');
        return node.value;
      case 'BooleanLiteral': return node.value;
      case 'NilLiteral': return null;
      case 'UnaryExpression':
        if (node.operator === '-' && node.argument.type === 'NumericLiteral') return -decode(node.argument, depth + 1);
        break;
      case 'TableConstructorExpression': {
        const result = Object.create(null);
        let index = 1;
        for (const field of node.fields) {
          let key;
          if (field.type === 'TableValue') key = index++;
          else if (field.type === 'TableKeyString') key = field.key.name;
          else if (field.type === 'TableKey') key = decode(field.key, depth + 1);
          else throw Error(`Unsupported table field: ${field.type}`);
          if (typeof key !== 'string' && typeof key !== 'number') throw Error('Invalid table key');
          key = String(key);
          if (Object.hasOwn(result, key)) throw Error(`Duplicate or ambiguous table key: ${key}`);
          result[key] = decode(field.value, depth + 1);
        }
        // Tuples with .n remain objects, including explicit numeric keys for nil holes.
        const keys = Object.keys(result);
        if (keys.length && keys.every((key, i) => key === String(i + 1))) return keys.map(key => result[key]);
        return result;
      }
    }
    throw Error(`Executable or unsupported Lua syntax: ${node.type}`);
  }
  if (ast.body.length !== 1) throw Error('Expected exactly one SavedVariables assignment');
  const assignment = ast.body[0];
  if (assignment.type !== 'AssignmentStatement' || assignment.variables.length !== 1 || assignment.init.length !== 1
    || assignment.variables[0].type !== 'Identifier' || assignment.variables[0].name !== 'ForeverLoggerDB') {
    throw Error('Expected ForeverLoggerDB = { ... }');
  }
  const db = decode(assignment.init[0]);
  if (!db || db.schemaVersion !== 1 || typeof db.installationID !== 'string') throw Error('Unsupported or invalid ForeverLogger schema');
  return db;
}
function array(value, label) {
  if (Array.isArray(value)) return value;
  if (value && typeof value === 'object' && Object.keys(value).length === 0) return [];
  throw Error(`${label} must be an array`);
}
function* records(db) {
  yield { type: 'database', schemaVersion: db.schemaVersion, installationID: db.installationID, settings: db.settings, retention: db.retention };
  for (const session of array(db.sessions, 'sessions')) {
    const { states, events, components, anchors, warnings, ...metadata } = session;
    const scope = { installationID: db.installationID, sessionID: session.id };
    const statesArray = array(states, 'states'), eventsArray = array(events, 'events');
    const ids = new Set();
    for (const state of statesArray) {
      if (typeof state.id !== 'string' || ids.has(state.id)) throw Error('Invalid or duplicate state ID');
      ids.add(state.id);
      for (const [kind, id] of Object.entries(state.components)) {
        if (!components[id] || components[id].kind !== kind) throw Error(`Invalid ${kind} component reference: ${id}`);
      }
    }
    for (const event of eventsArray) {
      if (event.stateID != null && !ids.has(event.stateID)) throw Error(`Dangling state reference: ${event.stateID}`);
    }
    yield { type: 'session', ...scope, data: metadata };
    for (const [id, data] of Object.entries(components)) yield { type: 'component', ...scope, id, data };
    // Emit records in observation sequence, with component dictionaries defined first.
    const timeline = [
      ...statesArray.map(data => ({ type: 'state', ...scope, data })),
      ...eventsArray.map(data => ({ type: 'event', ...scope, data })),
      ...array(anchors, 'anchors').map(data => ({ type: 'anchor', ...scope, data })),
      ...Object.values(warnings).map(data => ({ type: 'warning', ...scope, data })),
    ];
    timeline.sort((a, b) => a.data.seq - b.data.seq);
    for (const row of timeline) yield row;
  }
}
function resolveState(session, stateID) {
  const state = array(session.states, 'states').find(row => row.id === stateID);
  if (!state) throw Error(`Unknown state ID: ${stateID}`);
  return Object.fromEntries(Object.entries(state.components).map(([kind, id]) => {
    if (!session.components[id]) throw Error(`Unknown component: ${id}`);
    return [kind, session.components[id].data];
  }));
}
async function main() {
  const [input, output] = process.argv.slice(2);
  if (!input || !output) throw Error('Usage: node tools/export.cjs <ForeverLogger.lua> <output.jsonl>');
  const db = parseSavedVariables(fs.readFileSync(input));
  // Validate all references before opening the output file. Never overwrite existing exports.
  for (const row of records(db)) JSON.stringify(row);
  const stream = fs.createWriteStream(output, { flags: 'wx', encoding: 'utf8' });
  let streamError;
  stream.on('error', error => { streamError = error; });
  await once(stream, 'open');
  for (const row of records(db)) {
    if (streamError) throw streamError;
    if (!stream.write(JSON.stringify(row) + '\n')) await once(stream, 'drain');
  }
  stream.end();
  await once(stream, 'finish');
  console.log(`Exported ${array(db.sessions, 'sessions').length} session(s) to ${output}`);
}
if (require.main === module) main().catch(error => { console.error(error.message); process.exitCode = 1; });
module.exports = { parseSavedVariables, records, resolveState };
