# API research and compatibility contract

Research date: **2026-09-12** (local date). Primary baseline: Blizzard's shipped UI/API source, mirrored by Gethe, Classic Era commit **33e177d9bf38d76d5c6c6e05d5da78db1899659a**, whose `version.txt` is **1.15.9.69722**. These pinned links remain useful if the branch changes.

No verified Forever-specific API contract, client installation, or beta runtime was available during implementation. Public discussion is not treated as an API specification. The official site could not be retrieved through the research tool. Forever compatibility must be established on the actual beta client; restricted combat information must remain restricted.

## Primary sources

| Source | Implementation evidence |
| --- | --- |
| [Pinned client version](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/version.txt) | TOC 11509 baseline. |
| [Vanilla PaperDollFrame](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_CharacterFrame/Vanilla/PaperDollFrame.lua) | `UnitStat`, `UnitResistance`, `UnitArmor`, AP, damage, speed, defense/skill tuple order; inventory reads; hidden tooltip `SetInventoryItem`; optional `C_Engraving.GetRuneForEquipmentSlot`. |
| [TBC PaperDollFrame](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_CharacterFrame/TBC/PaperDollFrame.lua) | Optional spirit regeneration, expertise and penetration APIs. These are probed, not presumed to exist on Era. |
| [Cata PaperDollFrame](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_CharacterFrame/Cata/PaperDollFrame.lua) | Optional hit modifiers and melee/ranged/spell haste. Rating contributions and modifiers are stored separately, not assumed to equal a universal final hit chance. |
| [Vanilla TalentFrameBase](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_FrameXML/Vanilla/TalentFrameBase.lua) | Current Classic uses `GetNumTalents`, `C_SpecializationInfo.GetSpecializationInfo` and a structured `GetTalentInfo` query, including specialization/talent/group indices. |
| [SpecializationInfo generated definitions](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_APIDocumentationGenerated/SpecializationInfoDocumentation.lua) | Talent result fields include talentID, spellID, rank, maxRank, tier, column and prerequisites/availability. `GetActiveSpecGroup` identifies the live configuration. |
| [Classic Talent UI](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_TalentUI/Classic/Blizzard_TalentUI.lua) | `GetTalentLink` is still used for links; talent IDs are not interchangeable with spell IDs. |
| [Vanilla spellbook UI](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_UIPanels_Game/Vanilla/SpellBookFrame.lua) | Tab offset/count enumeration, `GetSpellBookItemInfo`, `GetSpellBookItemName`, `IsPassiveSpell`, and book-type semantics. |
| [SpellBook generated definitions](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_APIDocumentationGenerated/SpellBookDocumentation.lua) | Modern known-spell/override lookup, pet spell count, spellbook and cooldown event names. This Classic namespace does not expose the entire retail spellbook enumeration interface. |
| [Item generated definitions](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_APIDocumentationGenerated/ItemDocumentation.lua) | `C_Item.GetItemInfo` tuple, including optional setID; `GetItemGem`, `GetItemSpell` and asynchronous cache event. |
| [UnitAura generated definitions](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_APIDocumentationGenerated/UnitAuraDocumentation.lua) | `C_UnitAuras.GetAuraDataByIndex(unit, index, filter)`; explicit restrictions/private-aura APIs exist. The addon only reads public aura data. |
| [Aura shared structures](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_APIDocumentationGenerated/UnitAuraSharedDocumentation.lua) | Aura data preserves spell/instance IDs, applications, duration/expiry and sourceUnit where exposed. |
| [Spell generated definitions](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_APIDocumentationGenerated/SpellDocumentation.lua) | `C_Spell.GetSpellCooldown` / `GetSpellCharges` return structures; valid spell queries can return no result. |
| [CombatLog generated definitions](https://github.com/Gethe/wow-ui-source/blob/33e177d9bf38d76d5c6c6e05d5da78db1899659a/Interface/AddOns/Blizzard_APIDocumentationGenerated/CombatLogDocumentation.lua) | `C_CombatLog.IsCombatLogRestricted`, current-event access, and restricted event registration. No attempt is made to bypass restrictions. |

## Compatibility decisions

The adapter first uses the inspected current Classic talent and aura APIs, and falls back to older Classic global functions (`GetTalentInfo`, `GetTalentTabInfo`, `UnitAura`). Tuple-returning reads retain a `.raw` tuple in addition to named fields. Legacy talent links provide talent IDs where the older `GetTalentInfo` does not return them. No spell ID is manufactured from a talent ID or array position.

`LoggingCombat(true)` is called directly at login and every 30 seconds, with a second interval guard inside the logging module. There is no immediate verification query: even a query consumes the shared API rate limit. A nil return is recorded as unknown/rate-limited, never as success. The addon does not change `advancedCombatLogging`; it records the current CVar if available.

API function existence is recorded in `session.capabilities`; registration success in `registeredEvents`. `pcall` isolates API failures and backs off a failing function for ten seconds. A supported function can still return nil or partial data. Secret values are discarded before indexing/comparison/serialization, and unsupported types/cycles/deep structures are removed with quality warnings. No secret-data declassification, secure hooks, input synthesis, target changes, spell casts or protected-action automation are used.

Inventory tooltip reads use a dedicated hidden `GameTooltip`, protected by `pcall`, one slot per scheduler tick, only outside combat. Raw localized text is retained. English set thresholds/damage/speed/armor are labeled **tooltip-text inference**, not server combat rules. Other locales retain raw evidence for external analysis.

Do not replace feature detection with a guessed Forever branch. When a beta changes an API, add a fixture reproducing its actual observed signature, adapt the relevant collector, and update this contract and the TOC.
