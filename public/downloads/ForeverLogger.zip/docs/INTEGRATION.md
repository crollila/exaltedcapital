# Standalone logger integration handoff

This implementation writes local `ForeverLoggerDB.schemaVersion = 1`. Its release is **1.0.1**. Its schema and addon version are separate from shared bundle **1.0.0**. The integration lead added a native transport/analysis adapter without changing shared schema meanings; see [native integration](../../shared/integration/README.md). No conformance to sanitized shared capture/package schemas is claimed.

## Available producer contract

- Installation ID: `ForeverLoggerDB.installationID`, independent of character GUID/name. Generated from a local PRNG seeded by local epoch seconds, client uptime and one existing `math.random` sample; not cryptographic or globally guaranteed unique.
- Session key: `session.id = installationID:monotonicDatabaseCounter`. A login/reload or storage rotation starts a new session. No per-login nonce is currently included.
- Version: `session.addonVersion`, `session.schemaVersion`, `session.client.version/build/interface` (plus raw GetBuildInfo tuple). There is no `ForeverLoggerUploadInfo` global or root `wowBuild` field.
- Flush: PREPARE LOGS finalizes and reloads; collection automatically resumes in a new session after reload. Native logging stays enabled. This intentionally does not implement the uploader proposal that requires logging to stay stopped.
- Evidence: raw API tuples in reusable component records, state observations with collection intervals, separate supplementary event/anchor/warning arrays sharing an observation sequence. Native log remains an independent external file.
- Identity: local GUIDs are preserved for accurate native-log matching. Privacy sanitization and HMAC identities belong to an explicitly designed uploader adapter.
- Retention: version 1.0.1 pauses before allocating a session that would exceed retention capacity. It preserves every retained session and displays a storage-full warning. This does not create an in-game uploader acknowledgment; organizer-assisted archive/reset remains necessary after successful external preservation.

## Changes requiring coordinated integration

An adapter/new capture version needs actor IDs/maps, sealed capture keys with per-login entropy, a unified retained raw stream, explicit missing-sequence ranges, complete section coverage and units, relative time fields and verified clock discontinuity behavior, shared snapshot interpretations, deployment/epoch provenance, and uploader-compatible capacity handling. Many shared fields cannot be safely inferred by renaming existing keys; unknowns must remain unknown.

Proposed next boundary decision: retain standalone schema 1 as a supported import format and add a **new, explicitly versioned capture writer** only after the integration owner agrees how native combat-log files, sparse supplementary references, raw component deduplication and the no-acknowledgment budget pause map into the shared contract. Keep that version distinct from this release. Supply a synthetic fixture plus invalid/gap cases before dependent uploader changes. A wire-compatible fixture is not included because this writer does not yet produce that wire contract.

## Validation performed

`npm test`: Lua 5.1 syntax across 14 modules, 21 mocked addon integration cases, SavedVariables-to-JSONL round-trip and 6 exporter cases including CLI file creation/overwrite protection. `npm run package`: explicit addon-only release file allowlist. ZIP integrity and embedded TOC module bytes checked independently with Python's zipfile.

No actual Classic/Forever client, disk flush, taint or raid-performance test was performed. The final integration harness now executes these addon modules with manufactured API returns, sends their serialized output through the real Windows uploader and HTTPS server, and verifies normalized evidence. That does not establish real-client compatibility. The stable distribution is built with `node tools/package-addon-release.cjs`; `npm run package` remains a developer bundle. Existing staging paths are unchanged.
