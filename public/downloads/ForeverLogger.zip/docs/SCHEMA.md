# Schema 1

SavedVariables root: `ForeverLoggerDB`. The file contains ordinary Lua tables that WoW serializes. Do not load this file into a general Lua interpreter for untrusted inputs; use the supplied literal-only parser.

## Database and sessions

| Field | Meaning |
| --- | --- |
| `schemaVersion` | Integer 1. Unknown schemas are preserved and collection is disabled. |
| `installationID` | Random, persistent, non-cryptographic identifier, independent of character identity. Removing SavedVariables creates a new installation identity. |
| `nextSession`, `nextState` | Persistent installation counters. State IDs are globally increasing within this database. |
| `settings` | Collection intervals, UI visibility and capacity limits. |
| `retention` | Historical eviction counters from earlier releases; retained unchanged for compatibility. Addon 1.0.1 pauses at capacity and does not perform new evictions. |
| `sessions[]` | Retained sessions in creation order. |

Each session stores `id` (`installationID:counter`), schema/addon/client version, locale/projectID, collection settings, `started`, `ended`, start/end reasons, clock anchors, states, components, events, warnings, capability/registration observations, sequence counter and byte estimate. A session starts at login, reload, or automatic storage rotation. It spans characters only if the client itself changes the logged-in character without reloading; normal WoW character login creates a fresh session.

`recording` describes structured collection in memory. `nativeLogging` is a separately timestamped result of the last logging attempt. `saturatedAt` marks a storage-induced gap, `dropped` counts rejected storage write attempts, and `skippedClientEvents` counts incoming registered events ignored after saturation (not just player combat events). `incomplete` means a previous session was found without a persisted finalization; the addon cannot detect completely lost unsaved sessions.

## States and components

```lua
states = {
  {
    id = "state_1003", seq = 81,
    ts = { t = 12345.123456, u = 12345.12 },
    observedThrough = { t = 12345.125000, u = 12345.12 },
    previous = "state_1002", reason = "UNIT_AURA",
    changed = { "auras", "stats" },
    components = {
      player = "component_1", build = "component_2", equipment = "component_9",
      stats = "component_21", auras = "component_22", weaponEnchants = "component_6",
      context = "component_7", pet = "component_8",
    },
  },
}
components = {
  component_22 = { kind = "auras", observed = { t = 12345.123456, u = 12345.12 }, data = { ... } },
}
```

Component IDs are scoped to a session. State IDs are scoped to an installation. Resolve a state by following each named component reference, then reading its `data`. All references are explicit; replaying a chain of patches is unnecessary. Only changed components are stored again. A return to an earlier value creates a new component, avoiding unbounded content-hash indexes. State rows carry the complete component-reference map, not the entire player data.

The initial state contains every collector's result, including explicit unavailable/error results. Relevant events are observed immediately; identical results cause no new state. Short aura transitions are not deliberately debounced. A two-second audit catches otherwise unreported stats, auras, temporary enchants and context; a 30-second full audit also checks equipment, build, player and pet. Audits only observe the current value: a transient between audits can be missed.

`ts` is the callback/observation start; `observedThrough` is after the collectors finish. Reads are sequential, **not an atomic server snapshot**. An error replaces that component with an explicit error object and, when available, the previous component ID; it does not present stale values as a fresh successful read. Individual failed fields carry a status. Component observations remain at their original timestamps when reused.

## Supplementary event envelope

Every `events[]` row is `{ kind, seq, ts, stateID, data }`. `seq` orders states, events, anchors and first occurrences of warnings within the session. A missing stateID is valid for records written before the initial state or if initial capture failed. The exporter validates non-missing references.

| Kind | Data |
| --- | --- |
| `combat_ref` | Native `combatTimestamp`, subevent, sourceGUID/destGUID, spellID where the standard header provides it, and damage/heal/energize amount where applicable. No damage model or full native payload. Player and current-pet involvement only. |
| `cast` | Native unit-event name and argument tuple, spellID, current accessible power costs, available cast/channel timing, selected-target GUID, explicit warning that selected target may not be the cast target. SENT target names are removed. |
| `resources` | Player/pet health and maxima, current power type, active power, unmodified power units, mana, specific changed power if recognized, combo points. Identical observations per unit/token are omitted. |
| `cooldown` | Used-spell cooldown and charge observations; immediate at cast events, then coalesced to at most four scans per second on cooldown/charge events. Up to 128 distinct used player spells per addon load. |
| `item_cooldowns` | Equipped-slot cooldown tuples after cooldown events; changes only. |
| `target` | Selected target or focus GUID, level, creature/classification, health and accessible position at selection changes. |
| `position` | Once per second while in combat: player position/facing/speed and selected-target context. |
| `combat_boundary` | Entry/exit combat event, regardless of whether the context snapshot changed. |
| `totem` | Exposed totem data for the event's slot. |
| `client_event` | Encounter, movement-start/stop, auto-repeat and world-exit events with positional argument tuple. |
| `network` | Latency, bandwidth, FPS, spell queue window and advanced-log CVar observed every full audit. |
| `native_logging` | Attempt status and result, timestamped independently from structured recording. |
| `session_end` | Finalization reason when there is remaining capacity; `ended`/`endReason` still finalize a saturated session. |

## Timestamp domains and native-log joins

- `ts.t`: `GetTimePreciseSec()` when readable, falling back to `GetTime()`. High-resolution **client observation time**, not a promise of microsecond server accuracy.
- `ts.u`: `GetTime()` clock used by aura expiry, temporary-enchant expiry estimates and many cooldown APIs. This is preserved alongside the precision clock instead of assuming identical clock origins.
- `combatTimestamp`: the original combat-log event timestamp, unchanged. Do not assume its epoch or offset equals the local wall clock on every client.
- Each anchor brackets `GetServerTime()` and `time()` with before/after client readings, and stores local/UTC wall-time strings. Integer epoch resolution is **one second**, plus the bracket duration; interpolation cannot recover subsecond server accuracy.
- Aura `expirationTime` is client uptime seconds; `duration` is seconds. `expirationTime = 0` / `duration = 0` generally indicates a timeless aura, not a fabricated removal time. Source GUID can be absent.
- Temporary weapon enchant `expiresUptime` is calculated from observed remaining milliseconds; subsecond differences under one second are treated as countdown quantization, so very small refreshes can be missed. The enclosing component's observation is retained.
- Cast `startMS`/`endMS` and base cooldown fields ending `MS` are milliseconds. Spell cooldown start/duration are client seconds, plus API-provided rate modifiers. Stats expose API units and raw tuples; percentages are not fractions unless the field is explicitly a multiplier.

First match native combat entries to `combat_ref` rows by subevent, source/destination GUIDs, spellID and amount (if present), then timestamp and occurrence order. Repeated identical events can still be ambiguous. Use multiple matches to establish the native-file clock offset and check drift; do not silently choose among ambiguous candidates. Reference the matched row's stateID as the **most recent observed state at callback time**, not proof of which server-side snapshot was used to resolve that attack. For native events lacking references, use the observation timeline with its timestamp uncertainty and gaps.

## Missing and partial data

`API.Fields` returns `{ api, status, raw, ...namedFields }`. Status can be `ok`, `missing`, `error`, `backoff`, `restricted`, or `partial`. Raw multiple returns use `{ n = numberOfReturns, [1] = ..., [3] = ... }` so nil holes do not shift later values. An `ok` API call returning nil can mean not applicable, uncached or not exposed; it is **not zero**. Never impute missing ranks, IDs, sources or numeric stats as zero.

Modern aura/talent structures retain sanitized fields supplied by the client, so additional fields can appear without a schema change. Numeric array positions have the documented client semantics: equipment is an array of rows with explicit `.slot` 0–19; spell school array 1–7 maps to resistance API index 0–6; gem enchant IDs in item strings are not necessarily gem item IDs.

Warnings are a dictionary by stable code, with first/last timestamps, first sequence, count and initial detail. Repeats update counts instead of generating unlimited error rows; additional details are not retained for every occurrence. Types are capped at 250; `suppressedWarningTypes` counts suppression. Functions that are simply absent are also listed as `false` capabilities even without a separate warning.

JSONL output defines database/session/component records first, then timeline records in sequence order. Dense Lua arrays become JSON arrays; empty tables remain objects, and positional tuples with `.n` remain objects with numeric-string keys. Use `.n` to reconstruct nil holes.
