# Observability and data quality limits

## Not available from the client

The addon cannot discover hidden server formulas, RNG seeds, proc tables, internal cooldowns, server-side coefficients, undocumented hit tables, internal damage snapshots, exact latency compensation, or authoritative enemy armor/resistances. Those must be inferred externally from repeated controlled observations and native logs. Displayed stats are client estimates; no fitted coefficient is treated as a measured stat.

Private or secret aura/combat fields are omitted and flagged. Restrictions can prevent combat-log callbacks entirely; the session records whether registration worked, but successful registration does not guarantee event delivery. The addon cannot bypass those restrictions or reconstruct hidden data that was never exposed. `Recording: YES` indicates structured collection is active, not complete coverage or verified native-file writing.

## Player and build

Only the live talent configuration is enumerated, including all exposed rank-zero talents. Inactive talent groups, undisclosed beta loadouts and retail trait trees are not assumed to use Classic APIs. The old talent hyperlink ID is a talent ID, not a spell ID. The current Classic structured adapter preserves both when supplied.

Only enumerable spellbook entries and known flyout slots are captured; hidden spell ranks, arbitrary server abilities and some temporary grants may not appear. Observed cast spell IDs provide additional evidence. Skill rows hidden behind collapsed headers are recorded as incomplete; the addon does not expand the user's skill UI. Current weapon skill and defense APIs provide independent observations where available.

The GUID and item/spell links can identify a character or its gear. The installation identifier is pseudonymous and randomly generated, not cryptographically anonymous; GUIDs, rare loadouts, localized text, and raw tooltips can still be identifying. The addon intentionally omits names/chat/account data, but raw tooltip content supplied by the client or another addon can contain names. Nothing is transmitted automatically.

## Equipment and sets

Item links are preserved in full, including suffixes and later item-string fields that the client may add. Leading item/enchant/gem-enchant fields are parsed; future field semantics must be checked before interpreting them. Gem APIs may be absent on clients without sockets. A zero gem-enchant field does not imply an API failure.

`GetItemInfo` can return nil while uncached; subsequent cache events and audits add new observations. Tooltip metadata is obtained only while the item is still equipped, outside combat. An item equipped and removed entirely in combat can have its link recorded without ever obtaining a tooltip. Tooltips may round base damage/speed and reflect modifiers; they are not a guaranteed immutable item database. Effective current attack damage/speed are independently stored through `UnitDamage`, `UnitAttackSpeed` and `UnitRangedDamage`.

Set IDs and equipped slots are taken from item metadata. English set names, piece thresholds and bonus descriptions are inferred from tooltip text; `activeByPieceCount` only evaluates the displayed piece count. It does not prove the server applied the bonus or that a broken/disabled item contributes. Non-English locales retain raw tooltip text and colors for external parsing. Undisplayed custom bonuses, bonus spell IDs and effects with no aura cannot be identified reliably. Tooltip failures have bounded retries; equipment changes reset retry state.

Temporary enchant remaining time is sampled and converted to an approximate expiry; the enchant ID and charges are retained when exposed. Consumes are observed through resulting auras, temporary enchants, casts and item cooldowns. Food/potions with no visible aura or cast cannot always be classified or tied to an inventory item. Bag contents are not enumerated.

## Timing, combat and supplementary coverage

States represent sequential client observations, not atomic server state or exact attack-resolution order. Brief states between callbacks/audits can be missed; identical timestamps are ordered by sequence. Full state reads are never performed per combat-log event. Native-log join keys cover the player and the current pet, not every guardian, despawned pet or raid member. Summon attribution can be reconstructed from the native log where present.

Enemy auras and raid-wide state are not continuously tracked. Selected-target/focus context is a limited supplement; target GUID at a cast event is not guaranteed to identify mouseover, queued, ground-targeted or self-cast recipients. Native combat effects should supply authoritative source/destination attribution.

Health/power events only fire when the client reports changes, not every server resource tick. Only recognized changed-power tokens receive an additional specific power read. Cooldowns are observed for up to 128 used player spells, and equipped items; the 250 ms coalescing can miss very short resets. No global-cooldown spell ID is invented. Position samples are one per second in combat and may be unavailable in instances. Pet aura/stat APIs can return incomplete information.

Collection uses capped enumeration, change deduplication, a 100 ms scheduler, and one out-of-combat tooltip read per scheduler tick. State reads still have a cost, particularly large spellbooks and full audits. No in-client performance benchmark was possible during development. A future client with expensive APIs may need different collectors or intervals after measurement.

## Persistence and retention

There is no addon API to append arbitrary files or flush SavedVariables independently. The only provided manual flush is PREPARE LOGS from an out-of-combat hardware click. Reload/logout can stall briefly while WoW writes large SavedVariables. The addon never triggers an automatic reload or changes combat/gameplay settings besides enabling native logging.

Finite memory means finite retained history. Saturated sessions pause structured collection through the end of combat, record a gap, then rotate in memory only if capacity remains. Version 1.0.1 pauses with a visible storage warning instead of evicting retained sessions. UI reload does not clear history or restore full capacity. The estimated serialized-size budget is not a hard heap cap, and previously huge or manually modified databases can already be expensive to load before addon code runs. Exit WoW, upload and back up both native and structured originals, then have the organizer explicitly archive/reset closed-client logger data before resuming recording. No in-game uploader acknowledgment or automatic destructive cleanup is provided.

Tests use a mocked WoW environment. Actual client taint, protection behavior, native-log formats, disk flushes, localization and Forever beta restrictions require in-game verification.
