const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { parseSavedVariables, records, resolveState } = require('../tools/export.cjs');
const source = `ForeverLoggerDB = {
  schemaVersion = 1, installationID = "install_test", sessions = {
    { id = "session_1", components = { component_1 = { kind = "player", data = { level = 60, race = "人類" } } },
      states = { { id = "state_1", seq = 1, components = { player = "component_1" } } },
      events = { { seq = 2, stateID = "state_1", data = { n = 3, [1] = "cast", [3] = 101 } } },
      anchors = {}, warnings = {} }
  }
}`;
test('safe export preserves Unicode, tuple holes, and resolves state components', () => {
  const db = parseSavedVariables(Buffer.from(source));
  const rows = [...records(db)];
  assert.equal(rows.length, 5);
  assert.equal(resolveState(db.sessions[0], 'state_1').player.race, '人類');
  const tuple = db.sessions[0].events[0].data;
  assert.equal(tuple.n, 3); assert.equal(tuple[2], undefined); assert.equal(tuple[3], 101);
});
test('rejects executable Lua and multiple assignments', () => {
  assert.throws(() => parseSavedVariables('ForeverLoggerDB = os.execute("do not run")'), /Executable/);
  assert.throws(() => parseSavedVariables(source + '\nos.execute("do not run")'), /exactly one/);
  assert.throws(() => parseSavedVariables(source.replace('level = 60', 'level = 30 + 30')), /Executable/);
});
test('rejects corrupt schemas and dangling state/component references', () => {
  assert.throws(() => parseSavedVariables(source.replace('schemaVersion = 1', 'schemaVersion = 2')), /schema/);
  assert.throws(() => [...records(parseSavedVariables(source.replace('stateID = "state_1"', 'stateID = "missing"')))], /Dangling/);
  assert.throws(() => [...records(parseSavedVariables(source.replace('player = "component_1"', 'player = "missing"')))], /component/);
});
test('prototype keys are inert data and duplicate keys are rejected', () => {
  const db = parseSavedVariables(source.replace('level = 60', '["__proto__"] = { polluted = true }, level = 60'));
  assert.equal({}.polluted, undefined);
  assert.equal(resolveState(db.sessions[0], 'state_1').player.__proto__.polluted, true);
  assert.throws(() => parseSavedVariables(source.replace('level = 60', 'level = 60, level = 70')), /Duplicate/);
});
test('numeric byte escapes decode UTF-8 and BOM is accepted', () => {
  const db = parseSavedVariables(Buffer.from('\ufeff' + source.replace('人類', '\\228\\186\\186')));
  assert.equal(resolveState(db.sessions[0], 'state_1').player.race, '人');
});
test('CLI writes valid JSONL and refuses to overwrite an existing export', () => {
  const tempRoot = path.resolve(os.tmpdir());
  const dir = fs.mkdtempSync(path.join(tempRoot, 'foreverlogger-test-'));
  try {
    const input = path.join(dir, 'ForeverLogger.lua'), output = path.join(dir, 'output.jsonl');
    fs.writeFileSync(input, source);
    const tool = path.resolve(__dirname, '../tools/export.cjs');
    const first = spawnSync(process.execPath, [tool, input, output], { encoding: 'utf8' });
    assert.equal(first.status, 0, first.stderr);
    const contents = fs.readFileSync(output, 'utf8');
    assert.equal(contents.trimEnd().split('\n').map(JSON.parse).length, 5);
    const second = spawnSync(process.execPath, [tool, input, output], { encoding: 'utf8' });
    assert.notEqual(second.status, 0);
    assert.equal(fs.readFileSync(output, 'utf8'), contents);
  } finally {
    if (path.dirname(dir) !== tempRoot || !path.basename(dir).startsWith('foreverlogger-test-')) throw Error('Unsafe test cleanup path');
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
