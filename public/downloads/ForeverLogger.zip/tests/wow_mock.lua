F = {}
unpack = table.unpack
NOW, WALL, COMBAT, LEVEL, STACKS, LOG_CALLS, RELOADS = 100, 1800000000, false, 60, 1, 0, 0
LINK = "|cffffffff|Hitem:123:456:789:0:0:0:0:0:60:0|h[Test Sword]|h|r"
ITEM_READY = false
function GetTime() return NOW end
function GetTimePreciseSec() return NOW + 0.000125 end
function time() return WALL + math.floor(NOW) end
function date() return "2026-09-13 01:00:00" end
function GetServerTime() return WALL + math.floor(NOW) end
function GetBuildInfo() return "1.15.9", "69722", "Sep 2026", 11509 end
function GetLocale() return "enUS" end
WOW_PROJECT_ID = 2
function UnitGUID(unit) if unit == "player" then return "Player-TEST-1" elseif unit == "target" then return "Creature-0-1" end end
function UnitClass() return "Warrior", "WARRIOR", 1 end
function UnitRace() return "Human", "Human", 1 end
function UnitLevel() return LEVEL end
function UnitSex() return 2 end
function UnitFactionGroup() return "Alliance", "Alliance" end
function UnitStat(_, i) return 100 + i, 120 + i, 20, 0 end
function UnitDamage() return 100, 200, 0, 0, 5, 0, 1 end
function UnitAttackSpeed() return 2.6, nil end
function UnitAttackPower() return 200, 50, 0 end
function UnitHealth() return 3500 end
function UnitHealthMax() return 4000 end
function UnitPower(_, power) return power == 0 and 0 or 42 end
function UnitPowerMax() return 100 end
function UnitPowerType() return 1, "RAGE" end
function UnitAffectingCombat() return COMBAT end
function InCombatLockdown() return COMBAT end
function UnitIsDeadOrGhost() return false end
function GetNumTalentTabs() return 1 end
function GetNumTalents() return 2 end
function GetTalentTabInfo() return "Arms", 1, 5, "WarriorArms" end
function GetTalentInfo(_, i) return "Talent " .. i, 10, 1, i, i == 1 and 5 or 0, 5, false, true end
function GetTalentLink(_, i) return "|Htalent:" .. (1000 + i) .. ":5|h[Talent]|h" end
function GetTalentPrereqs() return 1, 1, true end
function GetNumSpellTabs() return 1 end
function GetSpellTabInfo() return "Arms", 1, 0, 2 end
function GetSpellBookItemInfo(i) return "SPELL", 100 + i end
function GetSpellBookItemName(i) return "Spell " .. i, "Rank 1", 100 + i end
function GetSpellLink(i) return "|Hspell:" .. (100 + i) .. "|h[Spell]|h" end
function IsPassiveSpell(i) return i == 2 end
function GetNumSkillLines() return 1 end
function GetSkillLineInfo() return "Weapon Skills", true, false, 0, 0, 0, 0 end
function GetInventoryItemLink(_, slot) if slot == 16 then return LINK end end
function GetInventoryItemID(_, slot) if slot == 16 then return 123 end end
function GetInventoryItemBroken() return false end
function GetInventoryItemDurability() return 100, 120 end
function GetItemInfo(link)
    if ITEM_READY then return "Test Sword", link, 4, 60, 60, "Weapon", "Sword", 1, "INVTYPE_WEAPON", 123, 0, 2, 7, 1, 0, 22 end
end
function GetItemStats() return { ITEM_MOD_STRENGTH_SHORT = 20 } end
function GetItemGem(_, i) if i == 1 then return "Test Gem", "|Hitem:900|h[Gem]|h" end end
function GetItemSpell() return nil end
function GetWeaponEnchantInfo() return true, 500000 - (NOW - 100) * 1000, 10, 42, false, nil, nil, nil end
function UnitAura(_, i, filter)
    if i == 1 and filter == "HELPFUL" and STACKS > 0 then return "Battle Shout", 1, STACKS, nil, 120, 220, "player", false, false, 6673 end
end
function GetNumShapeshiftForms() return 1 end
function GetShapeshiftForm() return 1 end
function GetShapeshiftFormInfo() return 1, true, true, 2457 end
function GetInstanceInfo() return "Test Zone", "none", 0, "", 0, 0, false, 1 end
function GetZoneText() return "Test Zone" end
function GetSubZoneText() return "Test Subzone" end
function GetInventoryItemCooldown() return 0, 0, 1 end
function GetSpellCooldown() return 100, 10, 1 end
function GetSpellCharges() return nil end
function LoggingCombat(value) assert(value == true); LOG_CALLS = LOG_CALLS + 1; return true end
function ReloadUI() assert(not COMBAT); RELOADS = RELOADS + 1 end
function CombatLogGetCurrentEventInfo()
    return WALL + NOW, "SPELL_DAMAGE", false, "Player-TEST-1", "playername", 1, 0, "Creature-0-1", "targetname", 1, 0, 101, "Spell", 1, 250
end
function UnitCastingInfo() return "Spell", "Spell", 1, 100000, 102000, false, "cast-1", false, 101 end
SlashCmdList, UIParent = {}, {}
local Widget = {}
Widget.__index = Widget
function Widget:SetScript(key, fn) self.scripts[key] = fn end
function Widget:RegisterEvent(event)
    if event == "RUNE_UPDATED" then error("Unknown event") end
    self.events[event] = true
end
function Widget:CreateTexture() return setmetatable({ scripts = {}, events = {} }, Widget) end
function Widget:CreateFontString() return self:CreateTexture() end
function Widget:SetText(text) self.textValue = text end
function Widget:Show() self.shown = true end
function Widget:Hide() self.shown = false end
function Widget:IsShown() return self.shown end
function Widget:Disable() self.disabled = true end
function Widget:Enable() self.disabled = false end
for _, name in ipairs({ "SetSize", "SetPoint", "SetAllPoints", "SetColorTexture", "SetJustifyH", "SetWidth", "SetOwner", "ClearLines" }) do Widget[name] = function() end end
function Widget:SetInventoryItem()
    assert(not COMBAT, "tooltip read in combat")
    local lines = { "Test Sword", "100 - 200 Damage", "Test Set (2/5)", "(2) Set: Gain strength." }
    for i, text in ipairs(lines) do
        local value = text
        _G["ForeverLoggerScanTooltipTextLeft" .. i] = { GetText = function() return value end, GetTextColor = function() return 0, 1, 0, 1 end }
    end
end
function Widget:NumLines() return 4 end
function CreateFrame() return setmetatable({ scripts = {}, events = {}, shown = true }, Widget) end
function Emit(event, ...) F.frame.scripts.OnEvent(F.frame, event, ...) end
function Tick(seconds) NOW = NOW + seconds; F.frame.scripts.OnUpdate(F.frame, seconds) end
