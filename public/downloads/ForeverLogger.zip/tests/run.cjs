const fs = require('node:fs');
const path = require('node:path');
const { lua, lauxlib, lualib, to_luastring, to_jsstring } = require('fengari');
const parse = require('luaparse');
const root = path.resolve(__dirname, '..');
const files = fs.readFileSync(path.join(root, 'ForeverLogger/ForeverLogger.toc'), 'utf8').split(/\r?\n/).filter(x => x.endsWith('.lua'));
for (const file of files) parse.parse(fs.readFileSync(path.join(root, 'ForeverLogger', file), 'utf8'), { luaVersion: '5.1' });
console.log(`Lua 5.1 syntax: ${files.length} modules`);
const L = lauxlib.luaL_newstate();
lualib.luaL_openlibs(L);
function run(source, name, addon = false) {
  let status = lauxlib.luaL_loadbuffer(L, to_luastring(source), null, to_luastring(name));
  if (status === lua.LUA_OK) {
    if (addon) { lua.lua_pushstring(L, to_luastring('ForeverLogger')); lua.lua_getglobal(L, to_luastring('F')); }
    status = lua.lua_pcall(L, addon ? 2 : 0, 0, 0);
  }
  if (status !== lua.LUA_OK) throw new Error(`${name}: ${to_jsstring(lua.lua_tostring(L, -1))}`);
}
run(fs.readFileSync(path.join(__dirname, 'wow_mock.lua'), 'utf8'), 'wow_mock');
for (const file of files) run(fs.readFileSync(path.join(root, 'ForeverLogger', file), 'utf8'), file, true);
run(fs.readFileSync(path.join(__dirname, 'addon.test.lua'), 'utf8'), 'addon.test');
lua.lua_getglobal(L, to_luastring('TEST_SAVED_VARIABLES'));
const saved = to_jsstring(lua.lua_tostring(L, -1));
const { parseSavedVariables, records } = require('../tools/export.cjs');
const data = parseSavedVariables(saved);
const rows = [...records(data)];
if (!rows.some(row => row.type === 'state')) throw Error('SavedVariables round-trip lost state data');
console.log(`SavedVariables round-trip: ${rows.length} validated JSONL records`);
