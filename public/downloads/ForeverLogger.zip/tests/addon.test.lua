local tests = 0
local function test(name, fn) fn(); tests = tests + 1; print("PASS " .. name) end
local function component(kind)
    return F.session.components[F.State.refs[kind]].data
end
test("login creates identity, initial state and logging without interaction", function()
    Emit("ADDON_LOADED", "ForeverLogger")
    Emit("PLAYER_LOGIN")
    assert(F.session and #F.session.states == 1)
    assert(LOG_CALLS == 1 and F.session.nativeLogging.enabled == true)
    assert(F.Storage.db.installationID:match("^install_"))
    assert(component("player").guid == "Player-TEST-1")
    assert(component("build").talents.trees[1].talents[2].rank == 0)
    assert(component("build").talents.trees[1].talents[1].talentID == 1001)
    assert(component("stats").damage.min == 100)
    assert(component("equipment").slots[17].itemString.enchantID == 456)
    assert(F.session.warnings["unsupported_event:RUNE_UPDATED"])
end)
test("repeated events deduplicate; short aura changes keep separate states", function()
    local n = #F.session.states
    Emit("UNIT_STATS", "player"); Emit("UNIT_AURA", "player")
    assert(#F.session.states == n)
    local equipmentID = F.State.refs.equipment
    STACKS = 2; Emit("UNIT_AURA", "player")
    STACKS = 0; Emit("UNIT_AURA", "player")
    assert(#F.session.states == n + 2)
    assert(F.State.refs.equipment == equipmentID)
    assert(F.session.states[n + 1].ts.t == F.session.states[n + 2].ts.t)
    assert(F.session.states[n + 1].seq < F.session.states[n + 2].seq)
end)
test("combat references retain exact state and native timestamp without state copies", function()
    local state, n = F.stateID, #F.session.states
    Emit("COMBAT_LOG_EVENT_UNFILTERED")
    local row = F.session.events[#F.session.events]
    assert(row.kind == "combat_ref" and row.stateID == state)
    assert(row.data.combatTimestamp == WALL + NOW and row.data.amount == 250)
    assert(row.data.player == nil and row.data.components == nil and #F.session.states == n)
end)
test("pet and unrelated unit events do not alter player state", function()
    local n = #F.session.states
    Emit("UNIT_AURA", "party1"); Emit("UNIT_STATS", "pet")
    assert(#F.session.states == n)
end)
test("item cache resolves asynchronously and tooltips stay outside combat", function()
    assert(component("equipment").slots[17].info.name == nil)
    COMBAT = true; Tick(0.2)
    assert(F.Equipment.tooltips[16] == nil and LOG_CALLS == 1)
    ITEM_READY = true; Emit("GET_ITEM_INFO_RECEIVED", 123, true)
    assert(component("equipment").slots[17].info.name == "Test Sword")
    COMBAT = false; Tick(0.2)
    assert(F.Equipment.tooltips[16] ~= nil)
    assert(component("equipment").slots[17].set.bonuses[1].activeByPieceCount == true)
end)
test("temporary enchant countdown does not create artificial changes", function()
    local before = F.State.refs.weaponEnchants
    NOW = NOW + 2
    F.State.Capture({ "weaponEnchants" }, "test")
    assert(F.State.refs.weaponEnchants == before)
end)
test("current Classic structured talent adapter preserves IDs and ranks", function()
    C_SpecializationInfo = {
        GetTalentInfo = function(q) assert(q.specializationIndex == 1); return { talentID = 700 + q.talentIndex, rank = 3, maxRank = 5, spellID = 800 } end,
        GetSpecializationInfo = function() return 1, "Arms", "", 1, "DAMAGER", 1, 6, "Arms", 0, true end,
        GetActiveSpecGroup = function() return 1 end,
    }
    Emit("PLAYER_TALENT_UPDATE")
    assert(component("build").talents.adapter == "classic_structured")
    assert(component("build").talents.trees[1].talents[1].talentID == 701)
    assert(component("build").talents.trees[1].talents[1].info.rank == 3)
end)
test("modern auras redact secret values without serializing them", function()
    local secret = {}
    issecretvalue = function(value) return rawequal(value, secret) end
    C_UnitAuras = { GetAuraDataByIndex = function(_, i, filter)
        if i == 1 and filter == "HELPFUL" then return { spellId = 123, name = "Aura", applications = secret, auraInstanceID = 42 } end
    end }
    Emit("UNIT_AURA", "player")
    local value = component("auras")
    assert(value.helpful[1].spellId == 123 and value.helpful[1].applications == nil)
    assert(value.status == "partial")
    assert(F.session.warnings["redacted:C_UnitAuras.GetAuraDataByIndex"])
end)
test("API failures back off and recover without killing recording", function()
    local calls = 0
    GetCritChance = function() calls = calls + 1; error("API changed") end
    Emit("UNIT_STATS", "player"); Emit("UNIT_STATS", "player")
    assert(calls == 1 and F.session.recording)
    GetCritChance = function() return 7 end
    NOW = NOW + 11; Emit("UNIT_STATS", "player")
    assert(component("stats").meleeCrit.percent == 7)
end)
test("unavailable clock precision falls back without warning recursion", function()
    local original = GetTimePreciseSec
    GetTimePreciseSec = function() error("clock unavailable") end
    F.Warn("test_clock_warning")
    assert(F.session.warnings.test_clock_warning.first.t == NOW)
    GetTimePreciseSec = original
end)
test("cast payloads preserve nil positions and remove target names", function()
    Emit("UNIT_SPELLCAST_SENT", "player", "Private Name", "cast-1", 101)
    local found
    for _, event in ipairs(F.session.events) do if event.kind == "cast" then found = event end end
    assert(found.data.args.n == 4 and found.data.args[2] == nil and found.data.args[3] == "cast-1")
end)
test("logging rate limit yields unknown instead of falsely claiming disabled", function()
    LoggingCombat = function() LOG_CALLS = LOG_CALLS + 1; return nil end
    NOW = NOW + 31; F.Combat.Logging()
    assert(F.session.nativeLogging.status == "unknown_rate_limited")
    local calls = LOG_CALLS; F.Combat.Logging(); assert(LOG_CALLS == calls)
end)
test("prepare in combat never reloads or queues a later reload", function()
    COMBAT = true; F.UI.frame.prepare.scripts.OnClick()
    assert(RELOADS == 0 and F.session.ended == nil)
    COMBAT = false; Tick(1)
    assert(RELOADS == 0)
end)
test("all state references resolve and sequence is strictly increasing", function()
    local ids, previous = {}, 0
    for _, state in ipairs(F.session.states) do
        assert(state.seq > previous); previous = state.seq; ids[state.id] = true
        for _, id in pairs(state.components) do assert(F.session.components[id]) end
    end
    for _, event in ipairs(F.session.events) do assert(event.stateID == nil or ids[event.stateID]) end
end)
test("sustained combat does not duplicate state or generate handler errors", function()
    F.Storage.db.settings.maxSessionBytes = 64 * 1024 * 1024 -- volume test, not a budget test
    local n, events = #F.session.states, #F.session.events
    for i = 1, 5000 do Emit("COMBAT_LOG_EVENT_UNFILTERED") end
    assert(#F.session.states == n and #F.session.events == events + 10000) -- legacy join refs + full PvE stream
    for code in pairs(F.session.warnings) do assert(not code:match("^handler_error:"), code) end
end)
test("storage saturation is explicit and never leaves dangling component references", function()
    F.Storage.db.settings.maxSessionBytes = F.session.estimatedBytes + 1
    local id, n = F.stateID, #F.session.states
    LEVEL = 61; Emit("PLAYER_LEVEL_UP", 61)
    assert(not F.session.recording and F.session.saturatedAt and F.session.warnings.storage_limit)
    assert(F.stateID == id and #F.session.states == n)
end)
test("saturated recording rotates automatically after combat with a fresh complete state", function()
    local old, sessionID = F.session, F.session.id
    COMBAT = true; Tick(1)
    assert(F.session == old and not F.session.recording)
    F.Storage.db.settings.maxSessionBytes = F.defaults.maxSessionBytes
    COMBAT = false; Tick(1)
    assert(F.session.id ~= sessionID and F.session.recording and old.endReason == "storage_rotation")
    assert(#F.session.states >= 1 and component("player").level == 61)
    assert(old.capabilities ~= F.session.capabilities)
    for _, state in ipairs(F.session.states) do for _, id in pairs(state.components) do assert(F.session.components[id]) end end
end)
test("reload errors resume recording and leave a quality warning", function()
    local original = ReloadUI
    ReloadUI = function() error("test reload failure") end
    F.UI.frame.prepare.scripts.OnClick()
    assert(F.session.recording and not F.session.ended and F.session.warnings.reload_failed)
    ReloadUI = original
end)
test("hardware prepare finalizes and calls reload synchronously", function()
    F.UI.frame.prepare.scripts.OnClick()
    assert(RELOADS == 1 and F.session.endReason == "prepare_logs" and F.session.ended)
end)
test("full retention pauses without evicting or changing old sessions", function()
    local db, installID = F.Storage.db, F.Storage.db.installationID
    local original, count, counter = db.sessions[1], #db.sessions, db.nextSession
    db.settings.maxSessions = 1
    F.State.Reset()
    assert(F.Storage.Start("test_retention") == nil and F.retentionFull)
    assert(#db.sessions == count and db.sessions[1] == original and db.nextSession == counter)
    assert(db.retention.evictedSessions == 0 and db.installationID == installID)
end)
test("schema mismatch preserves existing SavedVariables", function()
    local original = ForeverLoggerDB
    ForeverLoggerDB = { schemaVersion = 999, important = "preserve" }
    assert(F.Storage.Init() == false and ForeverLoggerDB.important == "preserve")
    ForeverLoggerDB = original
end)
local function serialize(v)
    if type(v) == "table" then
        local fields = {}
        for k, value in pairs(v) do fields[#fields + 1] = "[" .. serialize(k) .. "]=" .. serialize(value) end
        return "{" .. table.concat(fields, ",") .. "}"
    end
    if type(v) == "string" then return string.format("%q", v) end
    assert(type(v) == "number" or type(v) == "boolean", "unserializable value")
    return tostring(v)
end
TEST_SAVED_VARIABLES = "ForeverLoggerDB=" .. serialize(ForeverLoggerDB)
print(tests .. " addon tests passed")
