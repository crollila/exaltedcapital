# ForeverLogger

Automatic structured combat-mechanics observations. Install once; collection starts at login and continues with the optional status window hidden. The addon requires no external Lua libraries.

**Client baseline:** Blizzard Classic Era **1.15.9 / 11509**, inspected UI source build **69722**. Legacy and current Classic talent/aura adapters are included. **Forever beta (1.60.1.69876, 12.x addon API with secret values) is supported from 1.2.0 on, audited against the client's own API documentation but not yet run in game; see [Forever notes](docs/FOREVER.md).** Missing or restricted APIs are recorded as unavailable, not fabricated. See [API research](docs/API_RESEARCH.md).

## Install and retrieve logs

1. Extract `ForeverLogger.zip` (addon version 1.0.1) and copy its **ForeverLogger** directory to `<client>/Interface/AddOns/`.
2. Verify `<client>/Interface/AddOns/ForeverLogger/ForeverLogger.toc` exists without another enclosing folder.
3. Log in. Recording starts automatically. `LoggingCombat(true)` is attempted at most once every 30 seconds and is never turned off by the addon.

For a different Classic patch, “Load out of date AddOns” may be necessary. A Forever beta release needs its actual interface number and API behavior verified; a TOC edit alone does not prove compatibility.

The panel shows structured recording status, session number and events/state changes recorded. Close it to hide it persistently; `/foreverlogger` or `/flog` toggles it. Closing the panel does not stop collection.

To prepare files, click **PREPARE LOGS** outside combat. The addon records a final observation, finalizes the session, and calls `ReloadUI()` synchronously from the hardware click. WoW saves SavedVariables during reload; a new session starts automatically afterward. No automatic or delayed UI reload is used.

Copy both:

- `<client>/WTF/Account/<account>/SavedVariables/ForeverLogger.lua`
- `<client>/Logs/WoWCombatLog.txt`, or that client's native combat-log files.

The addon cannot read native log files, verify a successful disk write, or flush SavedVariables without reload/logout. Crashes can lose unsaved data.

## Coverage

Captures random installation ID, character GUID/class/race/level, every enumerable talent including rank zero, talent IDs/links/ranks/prerequisites, learned spells and accessible spell details, equipment and item-string fields, enchants/gems, item stats, effective weapon damage/speed, deferred tooltip evidence, set IDs and detected bonuses, combat stats and ratings, player auras and sources, temporary enchants, forms, zone/combat state and observable pet state.

Supplementary records cover player/pet combat-log join keys, cast timing and current costs, resource transitions, used-spell and equipped-item cooldown changes, target context, combat position samples, totems, encounter events, latency/FPS and clock anchors. Reusable components prevent buff changes from copying entire spellbooks/equipment. Combat records contain state IDs, not character copies.

Read [SCHEMA.md](docs/SCHEMA.md) for timestamp domains and native-log matching, and [LIMITATIONS.md](docs/LIMITATIONS.md) for unobservable mechanics and partial coverage. English tooltip parsing is labeled inference; other locales retain raw text. GUIDs and raw tooltip text can be identifying; there is no automatic transmission.

## Bounded retention

Defaults: 32 MiB estimated serialized bytes per session, 128 MiB across retained sessions, and 40 sessions. These are estimates, not heap guarantees. A saturated session pauses structured capture through combat, while native logging continues; outside combat a fresh in-memory session starts if capacity remains. This rotation does not flush disk. Version 1.0.1 never evicts an old session to make room: it pauses and displays a storage-full warning. Exit WoW and send logs. After server success, the organizer must back up the original files and explicitly archive/reset closed-client logger data to restore capacity. Local cache and server originals must remain available; unlimited history requires external storage.

Capacity/timing settings are in `ForeverLoggerDB.settings`; edit only with WoW fully closed and a backup. Values below the shipped defaults are clamped at initialization. Larger limits cost memory and longer load/save times.

**Integration boundary:** this is SavedVariables **schema 1**, not shared wire/capture schema **1.0.0**. The integration lead connected the existing native server profile through an explicit uploader adapter; native evidence remains private. No schema was relabeled and there is no in-game upload acknowledgment. See [integration handoff](docs/INTEGRATION.md) and [the tested integration](../shared/integration/README.md).

## Export, tests and packaging

Run from the release ZIP root, or the current workspace staging root:

```powershell
npm ci --ignore-scripts
npm test
node tools/export.cjs "C:\path\ForeverLogger.lua" "C:\analysis\session.jsonl"
npm run package
node tools/package-addon-release.cjs
```

The literal-only exporter does not execute Lua. It preserves UTF-8 and tuple holes, validates component/state references, and refuses to overwrite exports. `resolveState(session, stateID)` reconstructs a state for external analysis.

Validation covers Lua 5.1 syntax, mocked WoW integration, a 5,000-event combat run, storage rotation and retention, SavedVariables round-trip, and exporter/CLI checks. It does not establish in-game performance, actual disk flushing or Forever beta support. Use the [client checklist](docs/VALIDATION.md) before certifying a build.

## Workspace ownership

Existing source/tooling staging remains at `ForeverLogger/`, root `tools/`, root npm manifests, and the four addon test files in root `tests/`, as identified by the integration owner's staging inventory. This component owns the documents under `addon/docs/`. Packaging uses an explicit file allowlist and its own README, preserving concurrent uploader/server/simulator files. A later coordinated migration can move this staging work into `addon/`; no other component was moved to complete this addon.
