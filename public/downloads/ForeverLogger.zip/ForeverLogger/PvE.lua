local _, F = ...
local A, S = F.API, F.Storage
local P = { version = "1.0.0", nameplates = {} }
F.PvE = P
local function us(t) return math.floor(t * 1000000 + 0.5) end
function P.Reset()
    P.contextSeq, P.contextTime, P.sessionID, P.encounter, P.pull = nil, nil, F.session.id, nil, 0
    P.nameplates = {}
    P.lastSampleTime = nil
    F.session.pveTelemetryVersion = P.version
end
local function fresh()
    if P.sessionID ~= F.session.id then P.Reset() end
end
function P.UnitState(unit)
    local guid = A.Value("UnitGUID", unit)
    if not guid then return { unit = unit, status = "unavailable" } end
    local dead = A.Value("UnitIsDeadOrGhost", unit)
    local alive
    if type(dead) == "boolean" then alive = not dead end
    local isPlayer = A.Value("UnitIsPlayer", unit)
    local record = { unit = unit, guid = guid, status = "observed", alive = alive,
        isPlayer = isPlayer, connected = A.Value("UnitIsConnected", unit),
        class = A.Fields("UnitClass", { "name", "token", "id" }, unit),
        race = A.Fields("UnitRace", { "name", "token", "id" }, unit),
        role = A.Fields("UnitGroupRolesAssigned", { "role" }, unit),
        health = A.Fields("UnitHealth", { "value" }, unit), maxHealth = A.Fields("UnitHealthMax", { "value" }, unit),
        level = A.Value("UnitLevel", unit), classification = A.Value("UnitClassification", unit),
        creatureType = A.Value("UnitCreatureType", unit), combat = A.Value("UnitAffectingCombat", unit),
        targetGUID = A.Value("UnitGUID", unit .. "target"),
        position = A.Fields("UnitPosition", { "x", "y", "z", "instanceID" }, unit),
        speed = A.Fields("GetUnitSpeed", { "current", "run", "flight", "swim" }, unit),
        armor = A.Fields("UnitArmor", { "base", "effective", "armor", "positive", "negative" }, unit),
        threat = A.Fields("UnitDetailedThreatSituation", { "tanking", "status", "scaledPercent", "rawPercent", "value" }, "player", unit),
        auras = F.ReadAuras(unit), resistances = {},
        cast = A.Fields("UnitCastingInfo", { "name", "text", "texture", "startMS", "endMS", "tradeSkill", "castID", "notInterruptible", "spellID" }, unit),
        channel = A.Fields("UnitChannelInfo", { "name", "text", "texture", "startMS", "endMS", "tradeSkill", "notInterruptible", "spellID" }, unit),
    }
    if isPlayer == false then record.npcName = A.Value("UnitName", unit) end
    -- Preserve each indexed API observation; do not guess an armor/resist formula.
    for school = 0, 6 do
        record.resistances[school + 1] = A.Fields("UnitResistance", { "base", "total", "positive", "negative" }, unit, school)
    end
    return record
end
function P.Context(force)
    if not F.session or not F.session.recording then return end
    fresh()
    local start = F.Clock.Stamp()
    if not force and P.lastSampleTime and start.t - P.lastSampleTime < 1 then return end
    local roster, units, seen, tokens = {}, {}, {}, {}
    local raid = A.Value("IsInRaid")
    local count = A.Value("GetNumGroupMembers")
    local complete = type(raid) == "boolean" and type(count) == "number" and count >= 0 and count <= 40
    if raid == true and type(count) == "number" then
        for i = 1, math.min(40, count) do tokens[#tokens + 1] = "raid" .. i end
    else
        tokens[#tokens + 1] = "player"
        local party = A.Value("GetNumSubgroupMembers")
        if type(party) ~= "number" or party < 0 or party > 4 then complete = false; party = 0 end
        for i = 1, math.min(4, party) do tokens[#tokens + 1] = "party" .. i end
    end
    local function observe(unit, member)
        local value = P.UnitState(unit)
        if member then
            if not value.guid or value.alive == nil or seen[value.guid] then complete = false end
            roster[#roster + 1] = value
        elseif value.guid and not seen[value.guid] then units[#units + 1] = value end
        if value.guid then seen[value.guid] = true end
    end
    for _, token in ipairs(tokens) do observe(token, true) end
    for _, token in ipairs({ "target", "focus", "pet", "boss1", "boss2", "boss3", "boss4", "boss5" }) do observe(token) end
    local nameplates = 0
    for token in pairs(P.nameplates) do
        nameplates = nameplates + 1
        if nameplates <= 40 then observe(token) end
    end
    local location = { instance = A.Fields("GetInstanceInfo", { "name", "type", "difficultyID", "difficultyName", "maxPlayers", "dynamicDifficulty", "isDynamic", "instanceID", "instanceGroupSize" }),
        zoneText = A.Value("GetZoneText"), subzoneText = A.Value("GetSubZoneText"),
        map = A.Fields("C_Map.GetBestMapForUnit", { "id" }, "player"),
        playerPosition = A.Fields("UnitPosition", { "x", "y", "z", "instanceID" }, "player"),
        encounterID = P.encounter, pull = P.pull > 0 and P.pull or nil }
    local finish = F.Clock.Stamp()
    P.lastSampleTime = finish.t
    local row = S.Event("pve_context", { version = P.version, observed_from_us = us(start.t),
        observed_through_us = us(finish.t), location = location,
        roster = { actors = roster, complete = complete, reportedCount = count,
            meaning = "observed_group_at_collection_interval_not_ability_eligibility" }, units = units }, finish)
    if row then P.contextSeq, P.contextTime = row.seq, finish.t end
end
local function contextAt(ts)
    if P.contextTime and P.contextTime <= ts.t and ts.t - P.contextTime <= 2 then return P.contextSeq end
end
function P.Combat(values, ts)
    fresh()
    -- Capture every received event. Do not require a player/pet, raid or boss.
    -- No layout-derived NPC IDs or amounts are asserted by the capture layer.
    local clean, dropped = A.Clean(values)
    if dropped then F.Warn("pve_combat_redacted") end
    S.Event("pve_combat", { version = P.version, context_seq = contextAt(ts),
        header_profile = "cleu-modern-1", values = clean or { n = 0 } }, ts)
end
function P.Unit(event, unit, args, ts)
    fresh()
    if type(unit) ~= "string" then return end
    local clean = F.Copy(args)
    if event == "UNIT_SPELLCAST_SENT" then clean[2] = nil end
    local state = P.UnitState(unit)
    local finish = F.Clock.Stamp()
    S.Event("pve_unit", { version = P.version, context_seq = contextAt(ts), event = event,
        args = clean, actor = state, received_at_us = us(ts.t), observed_through_us = us(finish.t) }, finish)
    -- Explicit state-change notifications prevent an old roster silently carrying
    -- through a death/aura/target change. The next context sample restores it.
    P.contextSeq, P.contextTime = nil, nil
end
function P.Boundary(event, args, ts)
    fresh()
    if event == "PLAYER_REGEN_DISABLED" then P.pull = P.pull + 1 end
    if event == "ENCOUNTER_START" and type(args[1]) == "number" then P.encounter = args[1] end
    if event == "NAME_PLATE_UNIT_ADDED" then P.nameplates[args[1]] = true end
    if event == "NAME_PLATE_UNIT_REMOVED" then P.nameplates[args[1]] = nil end
    S.Event("pve_boundary", { version = P.version, event = event, args = args,
        context_seq = contextAt(ts), pull = P.pull > 0 and P.pull or nil, encounterID = P.encounter }, ts)
    if event == "ENCOUNTER_END" then P.encounter = nil end
    P.contextSeq, P.contextTime = nil, nil
    P.Context(event == 'PLAYER_REGEN_DISABLED' or event == 'ENCOUNTER_START' or event == 'GROUP_ROSTER_UPDATE')
end
