local _, F = ...
local A = F.API
-- Forever (game type camelot) runs the 12.x addon model: combat values can be secret and the
-- live combat log is not delivered to addons. This file records what the client let us observe,
-- so a consumer never reads a missing field as "did not happen".
local R = { version = "1.0.0" }
F.Restrictions = R
local TYPES = { Combat = 0, Encounter = 1, ChallengeMode = 2, PvPMatch = 3, Map = 4, Chat = 5 }
local function flag(path, ...)
    if not A.Has(path) then return "unknown" end
    local value = A.Value(path, ...)
    if type(value) ~= "boolean" then return "unknown" end
    return value
end
function R.Probe()
    local out = { version = R.version, states = {},
        secretModel = type(_G.issecretvalue) == "function",
        hasSecretRestrictions = flag("C_Secrets.HasSecretRestrictions"),
        aurasSecret = flag("C_Secrets.ShouldAurasBeSecret"),
        cooldownsSecret = flag("C_Secrets.ShouldCooldownsBeSecret"),
        unitStatsSecret = flag("C_Secrets.ShouldUnitStatsBeSecret"),
        combatLogRestricted = flag("C_CombatLog.IsCombatLogRestricted"),
        combatLogReader = A.Has("CombatLogGetCurrentEventInfo") or A.Has("C_CombatLog.GetCurrentEventInfo"),
        damageMeter = flag("C_DamageMeter.IsDamageMeterAvailable"),
        addonChatRestricted = flag("C_ChatInfo.AreOutgoingAddonChatMessagesRestricted"),
        nativeLogging = flag("C_ChatInfo.IsLoggingCombat"),
    }
    if type(Enum) == "table" and type(Enum.AddOnRestrictionType) == "table" then
        for name, value in pairs(Enum.AddOnRestrictionType) do if type(value) == "number" then TYPES[name] = value end end
    end
    for name, value in pairs(TYPES) do
        out.states[name] = A.Has("C_RestrictedActions.GetAddOnRestrictionState")
            and A.Value("C_RestrictedActions.GetAddOnRestrictionState", value) or "unknown"
    end
    return out
end
-- observed | restricted | unavailable | not_collected | unknown, per telemetry field family.
function R.Fields()
    local access, events = A.access, F.session and F.session.registeredEvents or {}
    local function api(...)
        local ok, restricted, missing = 0, 0, 0
        for _, path in ipairs({ ... }) do
            local row = access[path]
            if row then ok = ok + (row.ok or 0); restricted = restricted + (row.restricted or 0); missing = missing + (row.missing or 0) + (row.error or 0) end
        end
        if restricted > 0 and ok > 0 then return "observed_partly_restricted" end
        if restricted > 0 then return "restricted" end
        if ok > 0 then return "observed" end
        if missing > 0 then return "unavailable" end
        return "unknown"
    end
    local reader = A.Has("CombatLogGetCurrentEventInfo") or A.Has("C_CombatLog.GetCurrentEventInfo")
    local live = "unknown"
    if events.COMBAT_LOG_EVENT_UNFILTERED == false or not reader then live = "unavailable"
    elseif R.combatLogRows and R.combatLogRows > 0 then live = "observed"
    elseif A.Value("C_CombatLog.IsCombatLogRestricted") == true then live = "restricted" end
    return {
        live_combat_events = live,
        player_casts = events.UNIT_SPELLCAST_SUCCEEDED and api("UnitCastingInfo", "UnitChannelInfo") or "unavailable",
        player_auras = api("C_UnitAuras.GetAuraDataByIndex", "UnitAura"),
        cooldowns = api("C_Spell.GetSpellCooldown", "GetSpellCooldown"),
        health = api("UnitHealth"), power = api("UnitPower"),
        player_stats = api("UnitStat", "UnitAttackPower", "GetCritChance"),
        unit_identity = api("UnitGUID"),
        threat = api("UnitDetailedThreatSituation"),
        damage_meter = api("C_DamageMeter.GetCombatSessionSourceFromType"),
        swing_timer = events.PLAYER_SWING and "observed" or "unavailable",
        -- Never collected by design; the native combat log file is the source.
        enemy_casts = "not_collected", hit_tables = "not_collected", per_event_damage = live == "observed" and "observed" or "not_collected",
        meaning = "absence_of_a_field_is_not_evidence_the_mechanic_did_not_happen",
        strongerSources = { "WoWCombatLog file", "Warcraft Logs", "client data", "controlled test" },
    }
end
function R.Record(reason, ts)
    if not F.session then return end
    local probe = R.Probe()
    F.session.capabilityRecord = { probe = probe, fields = R.Fields(), apiAccess = F.Copy(A.access), reason = reason,
        client = F.session.client, addonVersion = F.version }
    F.Storage.Event("restrictions", { reason = reason, probe = probe }, ts)
end
function R.Changed(args, ts)
    -- Fired before a restriction activates and after it lifts: the last/first moment values are readable.
    F.Storage.Event("restriction_state", { type = args[1], state = args[2] }, ts)
    if args[2] ~= 2 then F.State.Capture({ "stats", "auras", "context" }, "restriction_boundary", ts) end
    if args[2] == 0 then F.Combat.Meter("restriction_lifted", ts) end
end
