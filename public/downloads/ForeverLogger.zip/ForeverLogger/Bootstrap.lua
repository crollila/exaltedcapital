local _, F = ...
F.version = "1.2.1"
F.schemaVersion = 1
F.collectors = {}
F.defaults = {
    showUI = true,
    auditSeconds = 30,
    fastAuditSeconds = 2,
    loggingSeconds = 30,
    -- A finite memory budget is necessary: WoW has no addon file-append API.
    -- Sized so the whole SavedVariables file stays inside the server's Lua parse budget
    -- (server/foreverlogger/config.py: max_savedvariables_bytes = 128 MiB). These are F.Size
    -- estimates, which over-count the serialized file, so the real file stays well under that.
    maxSessionBytes = 24 * 1024 * 1024,
    maxTotalBytes = 96 * 1024 * 1024,
    maxSessions = 40,
}
function F.Pack(...)
    return { n = select("#", ...), ... }
end
function F.Copy(value)
    if type(value) ~= "table" then return value end
    local out = {}
    for k, v in pairs(value) do out[k] = F.Copy(v) end
    return out
end
function F.Equal(a, b)
    if type(a) ~= type(b) then return false end
    if type(a) ~= "table" then return a == b end
    for k, v in pairs(a) do if not F.Equal(v, b[k]) then return false end end
    for k in pairs(b) do if a[k] == nil then return false end end
    return true
end
-- Serialized-size accounting, calibrated against a real 27.6 MB SavedVariables file (2026-09-17): the
-- previous model (64 per table, 32 per scalar, 2x strings) reported 3.3x the bytes WoW actually wrote.
-- WoW writes `["key"] = value,` one per line; this lands about 1.3x above the real file.
F.sizeModel = 2
function F.Size(value)
    local t = type(value)
    if t == "string" then return #value + 6 end
    if t ~= "table" then return 12 end
    local n = 8
    for k, v in pairs(value) do n = n + F.Size(k) + F.Size(v) end
    return n
end
function F.Collect(name, fn)
    F.collectors[name] = fn
end
