local _, F = ...
F.version = "1.0.1"
F.schemaVersion = 1
F.collectors = {}
F.defaults = {
    showUI = true,
    auditSeconds = 30,
    fastAuditSeconds = 2,
    loggingSeconds = 30,
    -- A finite memory budget is necessary: WoW has no addon file-append API.
    maxSessionBytes = 32 * 1024 * 1024,
    maxTotalBytes = 128 * 1024 * 1024,
    maxSessions = 40,
}
function F.Pack(...)
    return { n = select("#", ...), ... }
end
function F.Copy(value)
    if type(value) ~= "table" then return value end
    local out = {}
    for k, v in pairs(value) do out[k] = F.Copy(v) end
    return out
end
function F.Equal(a, b)
    if type(a) ~= type(b) then return false end
    if type(a) ~= "table" then return a == b end
    for k, v in pairs(a) do if not F.Equal(v, b[k]) then return false end end
    for k in pairs(b) do if a[k] == nil then return false end end
    return true
end
-- Conservative serialized-size accounting, not an exact Lua heap measurement.
function F.Size(value)
    local t = type(value)
    if t == "string" then return #value * 2 + 8 end
    if t ~= "table" then return 32 end
    local n = 64
    for k, v in pairs(value) do n = n + F.Size(k) + F.Size(v) end
    return n
end
function F.Collect(name, fn)
    F.collectors[name] = fn
end
