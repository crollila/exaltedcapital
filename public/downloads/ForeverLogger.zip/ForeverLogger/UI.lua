local _, F = ...
F.UI = {}
local A = F.API
-- The combat log cannot be started or stopped by addon code on 12.x clients (LoggingCombat is Blizzard-UI only, and a
-- secure macro button running "/combatlog" was tried on Forever 2026-09-17 and did nothing). The player types it.
local function nativeLoggingOn()
    local s = F.session
    return s and s.nativeLogging and s.nativeLogging.enabled == true
end
function F.UI.Update()
    local ui, s = F.UI.frame, F.session
    if not ui or not s then return end
    local inCombat = A.Value("InCombatLockdown")
    if inCombat then
        ui.prepare:Disable()
        ui.text:SetText("ForeverLogger\nRecording: " .. (F.session.recording and "YES" or "NO") .. "   Combat log: " .. (nativeLoggingOn() and "ON" or "OFF")
            .. "\nIn combat: PREPARE LOGS works again when it ends.")
        return
    end
    if F.retentionFull then
        ui.text:SetText(F.UI.confirmClear
            and "ForeverLogger\nClick again to DELETE the saved logs in game.\nOnly do this after StepSis Log Uploader\nhas sent them."
            or "ForeverLogger\nRecording PAUSED: saved log storage is full.\nExit WoW, send your logs with StepSis,\nthen come back and clear them here.")
        ui.prepare:SetText(F.UI.confirmClear and "YES, CLEAR THEM" or "CLEAR SENT LOGS")
        ui.prepare:Enable(); ui:Show()
        return
    end
    ui.prepare:SetText("PREPARE LOGS")
    ui.text:SetText("ForeverLogger\nRecording: " .. (s.recording and "YES" or "NO")
        .. "   Combat log: " .. (nativeLoggingOn() and "ON" or "OFF")
        .. "\nSession: " .. tostring(F.Storage.db.nextSession)
        .. "\nEvents/state changes recorded: " .. (#s.events + #s.states)
        .. (nativeLoggingOn() and "\nTo upload: type /combatlog (stops the log),\nthen PREPARE LOGS, then StepSis."
            or "\nCombat log is OFF: type /combatlog before your next fight."))
    ui.prepare:Enable()
end
local function setShown(shown)
    F.Storage.db.settings.showUI = shown
    if shown then F.UI.frame:Show() else F.UI.frame:Hide() end
end
local function createMinimapButton(frame)
    if not Minimap then return end
    local button = CreateFrame("Button", "ForeverLoggerMinimapButton", Minimap)
    button:SetSize(31, 31); button:SetFrameStrata("MEDIUM"); button:SetFrameLevel(8)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:RegisterForDrag("LeftButton")
    local overlay = button:CreateTexture(nil, "OVERLAY")
    overlay:SetSize(53, 53); overlay:SetPoint("TOPLEFT")
    overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    local icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetSize(20, 20); icon:SetPoint("TOPLEFT", 7, -5)
    icon:SetTexture("Interface\\Icons\\INV_Misc_Note_01")
    button.icon = icon
    local function place()
        local angle = math.rad(F.Storage.db.settings.minimapAngle or 200)
        button:ClearAllPoints()
        button:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * 80, math.sin(angle) * 80)
    end
    button:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            F.Storage.db.settings.minimapAngle = math.deg(math.atan2(cy / scale - my, cx / scale - mx))
            place()
        end)
    end)
    button:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    button:SetScript("OnClick", function() setShown(not frame:IsShown()) end)
    button:SetScript("OnEnter", function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("ForeverLogger")
        GameTooltip:AddLine("Click: show or hide the panel. Drag: move this button.", 1, 1, 1)
        GameTooltip:AddLine("Combat log: " .. (nativeLoggingOn() and "ON" or "OFF") .. "   Recording: " .. (F.session and F.session.recording and "YES" or "NO"), 1, 1, 1)
        GameTooltip:AddLine("To upload: /combatlog, then /preparelogs, then StepSis.", 1, 1, 1)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
    place()
    F.UI.minimap = button
end
function F.UI.Create()
    local frame = CreateFrame("Frame", "ForeverLoggerStatus", UIParent)
    frame:SetSize(280, 160)
    frame:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 20, -160)
    local bg = frame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(); bg:SetColorTexture(0.04, 0.04, 0.06, 0.85)
    frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.text:SetPoint("TOPLEFT", 12, -12); frame.text:SetJustifyH("LEFT")
    frame.text:SetWidth(258)
    frame.prepare = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.prepare:SetSize(125, 24); frame.prepare:SetPoint("BOTTOMLEFT", 10, 10)
    frame.prepare:SetText("PREPARE LOGS")
    frame.prepare:SetScript("OnClick", function()
        if not F.retentionFull then F.PrepareLogs(); return end
        if not F.UI.confirmClear then F.UI.confirmClear = true; F.UI.Update(); return end
        F.UI.confirmClear = nil
        -- Same hardware click: the reload starts a fresh session through the normal login path.
        if F.Storage.ClearSent() then local reload = F.API.Resolve("ReloadUI"); if reload then pcall(reload) end end
    end)
    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetSize(24, 24); close:SetPoint("TOPRIGHT", 2, 2)
    close:SetScript("OnClick", function() setShown(false) end)
    F.UI.frame = frame
    if not F.Storage.db.settings.showUI then frame:Hide() end
    createMinimapButton(frame)
    SLASH_FOREVERLOGGER1, SLASH_FOREVERLOGGER2 = "/foreverlogger", "/flog"
    SlashCmdList.FOREVERLOGGER = function(msg)
        msg = (msg or ""):lower():match("^%s*(%S*)")
        if msg == "prepare" then F.PrepareLogs(); return end
        setShown(not frame:IsShown())
    end
    -- Typed in chat = a hardware event, so the reload inside PrepareLogs is allowed here.
    SLASH_FOREVERLOGGERPREPARE1 = "/preparelogs"
    SlashCmdList.FOREVERLOGGERPREPARE = function()
        if F.retentionFull then
            setShown(true)
            if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("ForeverLogger: storage is full. Use CLEAR SENT LOGS on the panel after StepSis has uploaded.") end
            return
        end
        if A.Value("InCombatLockdown") or A.Value("UnitAffectingCombat", "player") then
            if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("ForeverLogger: leave combat first, then /preparelogs again.") end
            return
        end
        if nativeLoggingOn() then
            -- No addon code can stop the combat log on this client; the player's own command can.
            setShown(true)
            if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("ForeverLogger: type /combatlog first (that stops the combat log so the uploader can read it), then /preparelogs again.") end
            return
        end
        if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("ForeverLogger: saving your logs and reloading. Then open StepSis Log Uploader and click SEND.") end
        F.PrepareLogs()
    end
    F.UI.Update()
end
