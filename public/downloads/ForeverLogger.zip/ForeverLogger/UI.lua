local _, F = ...
F.UI = {}
function F.UI.Update()
    local ui, s = F.UI.frame, F.session
    if not ui or not s then return end
    if F.retentionFull then
        ui.text:SetText("ForeverLogger\nRecording PAUSED: saved log storage is full.\nExit WoW and send your logs.\nAsk your guild organizer to archive/reset saved logs.")
        ui.prepare:Disable(); ui:Show()
        return
    end
    ui.text:SetText("ForeverLogger\nRecording: " .. (s.recording and "YES" or "NO")
        .. "\nSession: " .. tostring(F.Storage.db.nextSession)
        .. "\nEvents/state changes recorded: " .. (#s.events + #s.states))
    if F.API.Value("InCombatLockdown") then ui.prepare:Disable() else ui.prepare:Enable() end
end
function F.UI.Create()
    local frame = CreateFrame("Frame", "ForeverLoggerStatus", UIParent)
    frame:SetSize(280, 134)
    frame:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 20, -160)
    local bg = frame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(); bg:SetColorTexture(0.04, 0.04, 0.06, 0.85)
    frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.text:SetPoint("TOPLEFT", 12, -12); frame.text:SetJustifyH("LEFT")
    frame.text:SetWidth(258)
    frame.prepare = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.prepare:SetSize(150, 24); frame.prepare:SetPoint("BOTTOMLEFT", 10, 10)
    frame.prepare:SetText("PREPARE LOGS")
    frame.prepare:SetScript("OnClick", function() F.PrepareLogs() end)
    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetSize(24, 24); close:SetPoint("TOPRIGHT", 2, 2)
    close:SetScript("OnClick", function() F.Storage.db.settings.showUI = false; frame:Hide() end)
    F.UI.frame = frame
    if not F.Storage.db.settings.showUI then frame:Hide() end
    SLASH_FOREVERLOGGER1, SLASH_FOREVERLOGGER2 = "/foreverlogger", "/flog"
    SlashCmdList.FOREVERLOGGER = function()
        local shown = not frame:IsShown()
        F.Storage.db.settings.showUI = shown
        if shown then frame:Show() else frame:Hide() end
    end
    F.UI.Update()
end
