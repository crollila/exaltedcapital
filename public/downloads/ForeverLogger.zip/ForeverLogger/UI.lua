local _, F = ...
F.UI = {}
function F.UI.Update()
    local ui, s = F.UI.frame, F.session
    if not ui or not s then return end
    if F.retentionFull then
        ui.text:SetText(F.UI.confirmClear
            and "ForeverLogger\nClick again to DELETE the saved logs in game.\nOnly do this after StepSis Log Uploader\nhas sent them."
            or "ForeverLogger\nRecording PAUSED: saved log storage is full.\nExit WoW, send your logs with StepSis,\nthen come back and clear them here.")
        ui.prepare:SetText(F.UI.confirmClear and "YES, CLEAR THEM" or "CLEAR SENT LOGS")
        ui.prepare:Enable(); ui:Show()
        return
    end
    ui.prepare:SetText("PREPARE LOGS")
    ui.text:SetText("ForeverLogger\nRecording: " .. (s.recording and "YES" or "NO")
        .. "\nSession: " .. tostring(F.Storage.db.nextSession)
        .. "\nEvents/state changes recorded: " .. (#s.events + #s.states))
    if F.API.Value("InCombatLockdown") then ui.prepare:Disable() else ui.prepare:Enable() end
end
function F.UI.Create()
    local frame = CreateFrame("Frame", "ForeverLoggerStatus", UIParent)
    frame:SetSize(280, 134)
    frame:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 20, -160)
    local bg = frame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(); bg:SetColorTexture(0.04, 0.04, 0.06, 0.85)
    frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.text:SetPoint("TOPLEFT", 12, -12); frame.text:SetJustifyH("LEFT")
    frame.text:SetWidth(258)
    frame.prepare = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.prepare:SetSize(150, 24); frame.prepare:SetPoint("BOTTOMLEFT", 10, 10)
    frame.prepare:SetText("PREPARE LOGS")
    frame.prepare:SetScript("OnClick", function()
        if not F.retentionFull then F.PrepareLogs(); return end
        if not F.UI.confirmClear then F.UI.confirmClear = true; F.UI.Update(); return end
        F.UI.confirmClear = nil
        -- Same hardware click: the reload starts a fresh session through the normal login path.
        if F.Storage.ClearSent() then local reload = F.API.Resolve("ReloadUI"); if reload then pcall(reload) end end
    end)
    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetSize(24, 24); close:SetPoint("TOPRIGHT", 2, 2)
    close:SetScript("OnClick", function() F.Storage.db.settings.showUI = false; frame:Hide() end)
    F.UI.frame = frame
    if not F.Storage.db.settings.showUI then frame:Hide() end
    SLASH_FOREVERLOGGER1, SLASH_FOREVERLOGGER2 = "/foreverlogger", "/flog"
    SlashCmdList.FOREVERLOGGER = function()
        local shown = not frame:IsShown()
        F.Storage.db.settings.showUI = shown
        if shown then frame:Show() else frame:Hide() end
    end
    F.UI.Update()
end
