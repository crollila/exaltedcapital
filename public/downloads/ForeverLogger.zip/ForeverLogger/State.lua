local _, F = ...
local State = { refs = {}, last = {}, nextComponent = 0 }
F.State = State
State.all = { "player", "build", "equipment", "stats", "auras", "weaponEnchants", "context", "pet" }
function State.Reset()
    State.refs, State.last, State.nextComponent = {}, {}, 0
    F.stateID = nil
end
function State.Capture(names, reason, ts)
    if not F.session or not F.session.recording then return end
    ts = ts or F.Clock.Stamp()
    local changes, pending = {}, {}
    for _, name in ipairs(names) do
        local ok, value = pcall(F.collectors[name])
        if not ok then
            F.Warn("collector_error:" .. name, { message = F.API.Clean(value) })
            value = { status = "collector_error", previousComponentID = State.refs[name] }
            -- Do not recursively chain the same failed component on every observation.
            if State.last[name] and State.last[name].status == "collector_error" then value = State.last[name] end
        end
        if not F.Equal(State.last[name], value) then
            changes[#changes + 1] = name
            pending[name] = value
        end
    end
    if #changes == 0 then return end
    local refs, components = F.Copy(State.refs), {}
    for _, name in ipairs(changes) do
        State.nextComponent = State.nextComponent + 1
        local id = "component_" .. State.nextComponent
        refs[name] = id
        components[id] = { kind = name, data = pending[name], observed = ts }
    end
    local row = { ts = ts, observedThrough = F.Clock.Stamp(), previous = F.stateID, reason = reason, changed = changes, components = refs }
    if not F.Storage.Reserve(F.Size(row) + F.Size(components)) then return end
    F.Storage.db.nextState = F.Storage.db.nextState + 1
    row.id = "state_" .. F.Storage.db.nextState
    row.seq = F.Storage.Sequence()
    for id, component in pairs(components) do F.session.components[id] = component end
    for name, value in pairs(pending) do State.last[name] = value end
    State.refs = refs
    F.session.states[#F.session.states + 1] = row
    F.stateID = row.id
    return row.id
end
