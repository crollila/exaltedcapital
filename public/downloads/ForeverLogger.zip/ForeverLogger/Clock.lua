local _, F = ...
F.Clock = {}
function F.Clock.Stamp()
    local u = GetTime()
    -- Clock reads must not call the warning path (warnings themselves need a timestamp).
    local t = u
    if type(GetTimePreciseSec) == "function" then
        local ok, value = pcall(GetTimePreciseSec)
        if ok and not (type(issecretvalue) == "function" and issecretvalue(value))
            and type(value) == "number" then t = value end
    end
    return { t = t, u = u }
end
function F.Clock.Anchor(reason)
    local before = F.Clock.Stamp()
    local server = F.API.Value("GetServerTime")
    local wall = F.API.Value("time")
    local after = F.Clock.Stamp()
    return {
        reason = reason, ts = before, after = after, serverEpoch = server,
        localEpoch = wall, localDate = F.API.Value("date", "%Y-%m-%d %H:%M:%S"),
        utcDate = F.API.Value("date", "!%Y-%m-%d %H:%M:%S"),
        epochResolutionSeconds = 1,
        monotonicSource = type(GetTimePreciseSec) == "function" and "GetTimePreciseSec_with_GetTime_fallback" or "GetTime",
    }
end
