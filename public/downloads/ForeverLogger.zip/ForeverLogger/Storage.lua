local _, F = ...
local S = {}
F.Storage = S
-- Below this much room left in the total budget a new session is not worth starting.
local MIN_SESSION_BYTES = 2 * 1024 * 1024
local function randomID()
    -- Private PRNG state: do not reseed WoW's shared math.random generator.
    local seed = ((F.API.Value("time") or 1) + math.floor(GetTime() * 1000000)
        + math.random(1, 1000000000)) % 2147483647
    if seed == 0 then seed = 1 end
    local parts = {}
    for i = 1, 5 do seed = (seed * 16807) % 2147483647; parts[i] = string.format("%08x", seed) end
    return "install_" .. table.concat(parts)
end
function S.Init()
    if ForeverLoggerDB ~= nil and (type(ForeverLoggerDB) ~= "table"
        or ForeverLoggerDB.schemaVersion ~= F.schemaVersion) then
        F.disabled = "Unsupported SavedVariables schema; existing data preserved"
        return false
    end
    if ForeverLoggerDB and (type(ForeverLoggerDB.settings) ~= "table" or type(ForeverLoggerDB.sessions) ~= "table"
        or type(ForeverLoggerDB.retention) ~= "table" or type(ForeverLoggerDB.installationID) ~= "string"
        or type(ForeverLoggerDB.nextSession) ~= "number" or type(ForeverLoggerDB.nextState) ~= "number") then
        F.disabled = "Malformed SavedVariables; existing data preserved"
        return false
    end
    ForeverLoggerDB = ForeverLoggerDB or {
        schemaVersion = F.schemaVersion, installationID = randomID(),
        nextSession = 0, nextState = 0, sessions = {}, settings = F.Copy(F.defaults),
        retention = { evictedSessions = 0 },
    }
    S.db = ForeverLoggerDB
    for k, v in pairs(F.defaults) do if S.db.settings[k] == nil then S.db.settings[k] = v end end
    -- Validate operational limits before using values editable in SavedVariables.
    for _, key in ipairs({ "auditSeconds", "fastAuditSeconds", "loggingSeconds" }) do
        local n = S.db.settings[key]
        if type(n) ~= "number" or n < F.defaults[key] then S.db.settings[key] = F.defaults[key] end
    end
    for _, key in ipairs({ "maxSessionBytes", "maxTotalBytes", "maxSessions" }) do
        local n = S.db.settings[key]
        -- Byte budgets are pinned: a larger file cannot be parsed server-side.
        if type(n) ~= "number" or n ~= F.defaults[key] and key ~= "maxSessions" or n < F.defaults[key] then S.db.settings[key] = F.defaults[key] end
    end
    return true
end
function S.Start(reason)
    local db = S.db
    local total = 0
    for _, s in ipairs(db.sessions) do total = total + (s.estimatedBytes or 0) end
    -- Budget what is actually left, rather than refusing to start unless a whole
    -- maximum-sized session still fits: that reserved the cap instead of spending it.
    local remaining = db.settings.maxTotalBytes - total
    local budget = math.min(db.settings.maxSessionBytes, remaining)
    if #db.sessions >= db.settings.maxSessions or budget < MIN_SESSION_BYTES then
        -- No durable-copy acknowledgement exists in native schema 1. Never evict
        -- evidence merely to start another session.
        F.retentionFull = true
        F.session = db.sessions[#db.sessions]
        return nil
    end
    F.retentionFull = false
    db.nextSession = db.nextSession + 1
    local previous = db.sessions[#db.sessions]
    if previous and not previous.ended then
        previous.incomplete = true
        previous.incompleteReason = "No finalization was persisted; tail may be missing"
    end
    -- Each session owns its capability observations; never mutate older sessions.
    F.API.capabilities = F.Copy(F.API.capabilities)
    F.API.access = {}
    local session = {
        id = db.installationID .. ":" .. db.nextSession,
        addonVersion = F.version, schemaVersion = F.schemaVersion,
        client = F.API.Fields("GetBuildInfo", { "version", "build", "buildDate", "interface" }),
        locale = F.API.Value("GetLocale"), projectID = WOW_PROJECT_ID,
        collectionSettings = F.Copy(db.settings),
        started = F.Clock.Stamp(), startReason = reason,
        anchors = {}, states = {}, components = {}, events = {}, warnings = {},
        capabilities = F.API.capabilities, registeredEvents = {},
        estimatedBytes = 2048, byteBudget = budget, sequence = 0, dropped = 0, recording = true,
    }
    F.session = session
    db.sessions[#db.sessions + 1] = session
    S.Anchor("session_start")
    return session
end
function S.Reserve(bytes)
    local s = F.session
    if not s or not s.recording then if s then s.dropped = s.dropped + 1 end; return false end
    local budget = math.min(s.byteBudget or S.db.settings.maxSessionBytes, S.db.settings.maxSessionBytes)
    if s.estimatedBytes + bytes > budget then
        s.recording = false
        s.saturatedAt = F.Clock.Stamp()
        s.dropped = s.dropped + 1
        F.Warn("storage_limit", { limit = budget, nativeLogContinues = true })
        return false
    end
    s.estimatedBytes = s.estimatedBytes + bytes
    return true
end
function S.Sequence()
    F.session.sequence = F.session.sequence + 1
    return F.session.sequence
end
function S.Event(kind, data, ts)
    if not F.session then return end
    local row = { kind = kind, ts = ts or F.Clock.Stamp(), stateID = F.stateID, data = data }
    if not S.Reserve(F.Size(row)) then return end
    row.seq = S.Sequence()
    F.session.events[#F.session.events + 1] = row
    return row
end
function S.Anchor(reason)
    local row = F.Clock.Anchor(reason)
    if S.Reserve(F.Size(row)) then
        row.seq = S.Sequence()
        F.session.anchors[#F.session.anchors + 1] = row
    end
end
function F.Warn(code, detail)
    local s = F.session
    if not s then return end
    local row = s.warnings[code]
    if row then row.count = row.count + 1; row.last = F.Clock.Stamp(); return end
    local count = 0
    for _ in pairs(s.warnings) do count = count + 1 end
    if count >= 250 then s.suppressedWarningTypes = (s.suppressedWarningTypes or 0) + 1; return end
    local ts = F.Clock.Stamp()
    row = { code = code, detail = detail, count = 1, first = ts, last = ts, seq = S.Sequence() }
    s.warnings[code] = row
    s.estimatedBytes = s.estimatedBytes + F.Size(row)
end
function S.Finalize(reason)
    if not F.session or F.session.ended then return end
    S.Anchor(reason)
    S.Event("session_end", { reason = reason })
    F.session.ended = F.Clock.Stamp()
    F.session.endReason = reason
    F.session.recording = false
end
