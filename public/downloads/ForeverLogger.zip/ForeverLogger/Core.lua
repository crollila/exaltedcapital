local _, F = ...
local A, S = F.API, F.Storage
local frame = CreateFrame("Frame")
F.frame = frame
local routes = {
    PLAYER_EQUIPMENT_CHANGED = { "equipment", "stats", "weaponEnchants" },
    UNIT_INVENTORY_CHANGED = { "equipment", "stats", "weaponEnchants" },
    -- Durability ticks on every hit taken; the 20+ KB equipment component must not be re-captured for them.
    UPDATE_INVENTORY_DURABILITY = { "stats" },
    GET_ITEM_INFO_RECEIVED = { "equipment" }, ITEM_DATA_LOAD_RESULT = { "equipment" },
    PLAYER_TALENT_UPDATE = { "build", "stats", "auras" }, CHARACTER_POINTS_CHANGED = { "build", "stats" },
    ACTIVE_TALENT_GROUP_CHANGED = { "build", "stats", "auras" },
    PLAYER_LEVEL_UP = { "player", "build", "stats" },
    SPELLS_CHANGED = { "build", "context" }, LEARNED_SPELL_IN_TAB = { "build" }, LEARNED_SPELL_IN_SKILL_LINE = { "build" },
    SKILL_LINES_CHANGED = { "build", "stats" },
    UNIT_STATS = { "stats" }, UNIT_ATTACK_POWER = { "stats" }, UNIT_RANGED_ATTACK_POWER = { "stats" },
    UNIT_DAMAGE = { "stats" }, UNIT_ATTACK_SPEED = { "stats" }, UNIT_RANGEDDAMAGE = { "stats" },
    UNIT_RESISTANCES = { "stats" }, UNIT_DEFENSE = { "stats" }, COMBAT_RATING_UPDATE = { "stats" },
    UNIT_MAXHEALTH = { "stats" }, UNIT_MAXPOWER = { "stats" }, SPELL_POWER_CHANGED = { "stats" },
    UNIT_AURA = { "auras", "stats", "weaponEnchants" },
    UPDATE_SHAPESHIFT_FORM = { "context", "stats", "auras" }, UPDATE_SHAPESHIFT_FORMS = { "context", "build" },
    UNIT_DISPLAYPOWER = { "context", "stats" },
    PLAYER_REGEN_DISABLED = { "context", "stats", "auras" }, PLAYER_REGEN_ENABLED = { "context", "stats", "auras" },
    PLAYER_DEAD = { "context" }, PLAYER_ALIVE = { "context", "auras", "stats" }, PLAYER_UNGHOST = { "context", "stats" },
    PLAYER_UPDATE_RESTING = { "context" }, PLAYER_FLAGS_CHANGED = { "context" },
    ZONE_CHANGED = { "context" }, ZONE_CHANGED_INDOORS = { "context" }, ZONE_CHANGED_NEW_AREA = { "context" },
    UNIT_PET = { "pet", "context" }, PET_BAR_UPDATE = { "pet" }, UNIT_HAPPINESS = { "pet" },
    RUNE_UPDATED = { "equipment", "build", "stats" },
}
local supplementary = {
    "COMBAT_LOG_EVENT_UNFILTERED", "UNIT_HEALTH", "UNIT_HEALTH_FREQUENT", "UNIT_POWER_UPDATE", "UNIT_POWER_FREQUENT",
    "UNIT_SPELLCAST_SENT", "UNIT_SPELLCAST_START", "UNIT_SPELLCAST_STOP", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_FAILED",
    "UNIT_SPELLCAST_FAILED_QUIET", "UNIT_SPELLCAST_INTERRUPTED", "UNIT_SPELLCAST_DELAYED",
    "UNIT_SPELLCAST_CHANNEL_START", "UNIT_SPELLCAST_CHANNEL_UPDATE", "UNIT_SPELLCAST_CHANNEL_STOP",
    "SPELL_UPDATE_COOLDOWN", "SPELL_UPDATE_CHARGES", "BAG_UPDATE_COOLDOWN",
    "PLAYER_TARGET_CHANGED", "PLAYER_FOCUS_CHANGED", "PLAYER_STARTED_MOVING", "PLAYER_STOPPED_MOVING",
    "START_AUTOREPEAT_SPELL", "STOP_AUTOREPEAT_SPELL", "PLAYER_TOTEM_UPDATE",
    "ENCOUNTER_START", "ENCOUNTER_END", "PLAYER_ENTERING_WORLD", "PLAYER_LEAVING_WORLD", "PLAYER_LOGOUT",
    "GROUP_ROSTER_UPDATE", "NAME_PLATE_UNIT_ADDED", "NAME_PLATE_UNIT_REMOVED",
    "UNIT_TARGET", "UNIT_THREAT_LIST_UPDATE", "UNIT_THREAT_SITUATION_UPDATE",
    -- 12.x / Forever
    "ADDON_RESTRICTION_STATE_CHANGED", "PLAYER_SWING", "UNIT_COMBAT", "TRAIT_CONFIG_UPDATED",
    "DAMAGE_METER_COMBAT_SESSION_UPDATED",
}
-- A full unit scan per event is only worth it for events that change roster-relevant state.
local noUnitScan = { UNIT_HEALTH = true, UNIT_HEALTH_FREQUENT = true, UNIT_POWER_UPDATE = true, UNIT_POWER_FREQUENT = true,
    UNIT_COMBAT = true, UNIT_MAXHEALTH = true, UNIT_MAXPOWER = true }
local lastUnitScan = {}
-- Full per-unit records only for units that matter to the group; nameplate mobs get roster/context coverage only.
local unitRecordTokens = { player = true, pet = true, target = true, focus = true }
for i = 1, 4 do unitRecordTokens["party" .. i] = true end
for i = 1, 40 do unitRecordTokens["raid" .. i] = true end
for i = 1, 5 do unitRecordTokens["boss" .. i] = true; unitRecordTokens["arena" .. i] = true end
local function register(event)
    if event == "COMBAT_LOG_EVENT_UNFILTERED" and (A.Has("C_CombatLog.IsCombatLogRestricted")
        or not (A.Has("CombatLogGetCurrentEventInfo") or A.Has("C_CombatLog.GetCurrentEventInfo"))) then
        -- 12.x: the event is Blizzard-UI only (HasRestrictions). Registering it is the forbidden action itself
        -- (reported as UNKNOWN(), since it is a frame method), so it must not be attempted. The native combat
        -- log file is the per-event source on these clients.
        F.session.registeredEvents[event] = false
        F.Warn("combat_log_event_restricted")
        return
    end
    local ok = pcall(frame.RegisterEvent, frame, event)
    F.session.registeredEvents[event] = ok
    if not ok then F.Warn("unsupported_event:" .. event) end
end
function F.PrepareLogs()
    if F.retentionFull then return end
    if not F.session then return end
    if A.Value("InCombatLockdown") or A.Value("UnitAffectingCombat", "player") then
        F.Warn("prepare_refused_in_combat")
        return -- No delayed reload: another hardware click is required after combat.
    end
    local reload = A.Resolve("ReloadUI")
    if not reload then F.Warn("reload_unavailable"); return end
    F.State.Capture(F.State.all, "prepare_logs")
    F.Restrictions.Record("prepare_logs")
    S.Finalize("prepare_logs")
    -- Synchronous call chain from the button's OnClick; no timer or automatic reload.
    local ok = pcall(reload)
    if not ok then
        F.session.ended, F.session.endReason = nil, nil
        F.session.recording = F.session.saturatedAt == nil
        F.Warn("reload_failed")
    end
end
local function handle(event, ...)
    if event == "ADDON_ACTION_FORBIDDEN" or event == "ADDON_ACTION_BLOCKED" then
        -- The client names the function it refused; surface it so a restricted call can be removed, not guessed at.
        local addon, func = ...
        if addon == "ForeverLogger" then
            F.Warn("blocked_action", { event = event, func = A.Clean(func) })
            if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("ForeverLogger: the client blocked " .. tostring(func) .. " (" .. event .. "). Please report this line.") end
        end
        return
    end
    if event == "ADDON_LOADED" then
        local name = ...
        if name == "ForeverLogger" then
            if not S.Init() and DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("ForeverLogger: " .. F.disabled) end
        end
        return
    end
    if event == "PLAYER_LOGIN" then
        if not S.db then return end
        if not S.Start("login_or_reload") then F.UI.Create(); F.UI.Update(); return end
        for name in pairs(routes) do register(name) end
        for _, name in ipairs(supplementary) do register(name) end
        F.State.Capture(F.State.all, "initial")
        F.PvE.Reset()
        F.PvE.Context(true)
        F.Restrictions.Record("login")
        F.Combat.Logging()
        F.Combat.Resources("player")
        S.Event("target", F.ReadTarget("target"))
        F.UI.Create()
        return
    end
    if not F.session or F.retentionFull then return end
    local ts = F.Clock.Stamp()
    if event == "PLAYER_LOGOUT" then
        F.State.Capture(F.State.all, event, ts)
        F.Restrictions.Record("logout", ts)
        S.Finalize("logout_or_reload")
        return
    end
    if not F.session.recording then
        F.session.skippedClientEvents = (F.session.skippedClientEvents or 0) + 1
        return
    end
    local args, dropped = A.Clean(F.Pack(...))
    if dropped then F.Warn("redacted_event:" .. event) end
    local unit = args[1]
    if event:match("^UNIT_") and not noUnitScan[event] and type(unit) == "string" and unitRecordTokens[unit]
        and (unit == "player" or (lastUnitScan[unit] or 0) + 1 <= ts.u) then
        lastUnitScan[unit] = ts.u
        F.PvE.Unit(event, unit, args, ts)
    end
    if event == "ADDON_RESTRICTION_STATE_CHANGED" then F.Restrictions.Changed(args, ts); return end
    if event == "DAMAGE_METER_COMBAT_SESSION_UPDATED" then F.Combat.Meter(event, ts); return end
    if event == "TRAIT_CONFIG_UPDATED" then F.State.Capture({ "build", "stats" }, event, ts); return end
    if event:match("^ENCOUNTER_") or event:match("^ZONE_") or event:match("^NAME_PLATE_")
        or event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED"
        or event == "GROUP_ROSTER_UPDATE" or event == "PLAYER_ENTERING_WORLD"
        or event == "PLAYER_TARGET_CHANGED" or event == "PLAYER_FOCUS_CHANGED" then
        F.PvE.Boundary(event, args, ts)
    end
    if event:match("^UNIT_") and unit ~= "player" and unit ~= "pet" then return end
    if event == "COMBAT_LOG_EVENT_UNFILTERED" then F.Combat.Log(ts); return end
    if event:match("^UNIT_SPELLCAST_") then F.Combat.Cast(event, args, ts); return end
    if event == "UNIT_HEALTH" or event == "UNIT_HEALTH_FREQUENT" or event == "UNIT_POWER_UPDATE" or event == "UNIT_POWER_FREQUENT" then
        F.Combat.Resources(unit, args[2], ts); return
    end
    local route = routes[event]
    if route then
        if event == "PLAYER_EQUIPMENT_CHANGED" or event == "UNIT_INVENTORY_CHANGED" then F.Equipment.Invalidate() end
        if event == "GET_ITEM_INFO_RECEIVED" or event == "ITEM_DATA_LOAD_RESULT" then
            -- Avoid scanning equipment for unrelated bag items or tooltip-cache traffic.
            local found = false
            for slot = 0, 19 do if A.Value("GetInventoryItemID", "player", slot) == args[1] then found = true; break end end
            if not found then return end
        end
        if unit == "pet" and event:match("^UNIT_") then route = { "pet" } end
        F.State.Capture(route, event, ts)
        if event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" then
            S.Event("combat_boundary", { event = event }, ts)
            F.Restrictions.Record(event, ts)
            if event == "PLAYER_REGEN_ENABLED" then F.Combat.Meter(event, ts) end
        end
    elseif event == "PLAYER_ENTERING_WORLD" then
        F.Equipment.Invalidate()
        F.State.Capture(F.State.all, event, ts)
        S.Anchor(event)
    elseif event == "SPELL_UPDATE_COOLDOWN" or event == "SPELL_UPDATE_CHARGES" or event == "BAG_UPDATE_COOLDOWN" then
        F.Combat.cooldownDirty = true
    elseif event == "PLAYER_TARGET_CHANGED" or event == "PLAYER_FOCUS_CHANGED" then
        S.Event("target", F.ReadTarget(event == "PLAYER_FOCUS_CHANGED" and "focus" or "target"), ts)
    elseif event == "PLAYER_TOTEM_UPDATE" then
        S.Event("totem", A.Fields("GetTotemInfo", { "present", "name", "start", "duration", "icon", "modRate", "spellID" }, args[1]), ts)
    else S.Event("client_event", { event = event, args = args }, ts) end
end
local function guarded(event, ...)
    local ok, message = pcall(handle, event, ...)
    if not ok then
        if F.session then F.Warn("handler_error:" .. event, { message = A.Clean(message) })
        elseif DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("ForeverLogger could not initialize; existing data was preserved.") end
    end
end
frame:SetScript("OnEvent", function(_, event, ...) guarded(event, ...) end)
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
pcall(frame.RegisterEvent, frame, "ADDON_ACTION_FORBIDDEN")
pcall(frame.RegisterEvent, frame, "ADDON_ACTION_BLOCKED")
local elapsedTotal, nextFast, nextAudit, nextLogging, nextUI, nextCooldown, nextPosition = 0, 0, 0, 0, 0, 0, 0
local function update(elapsed)
    if F.retentionFull then return end
    if not F.session or F.session.ended then return end
    elapsedTotal = elapsedTotal + elapsed
    if elapsedTotal < 0.1 then return end
    elapsedTotal = 0
    local now = GetTime()
    if F.session.saturatedAt and not A.Value("InCombatLockdown") and not A.Value("UnitAffectingCombat", "player") then
        local registered = F.Copy(F.session.registeredEvents)
        S.Finalize("storage_rotation")
        F.State.Reset()
        F.Equipment.Invalidate()
        F.Combat.resources, F.Combat.cooldowns = {}, {}
        if not S.Start("storage_rotation") then F.UI.Update(); return end
        F.session.registeredEvents = registered
        F.State.Capture(F.State.all, "storage_rotation")
        F.Combat.Resources("player")
    end
    if now >= nextUI then nextUI = now + 1; F.UI.Update() end
    if now >= nextLogging then
        nextLogging = now + (A.Has("C_ChatInfo.IsLoggingCombat") and 1 or S.db.settings.loggingSeconds)
        F.Combat.Logging(); F.UI.Update()
    end
    if not F.session.recording then return end
    F.PvE.Context(false)
    F.Equipment.Pump()
    if now >= nextFast then
        nextFast = now + S.db.settings.fastAuditSeconds
        F.State.Capture({ "stats", "auras", "weaponEnchants", "context" }, "periodic_fast_audit")
    end
    if now >= nextAudit then
        nextAudit = now + S.db.settings.auditSeconds
        F.State.Capture(F.State.all, "periodic_full_audit")
        S.Anchor("periodic")
        S.Event("network", { net = A.Fields("GetNetStats", { "inKB", "outKB", "homeMS", "worldMS" }), fps = A.Value("GetFramerate"),
            spellQueueWindow = A.Value("GetCVar", "SpellQueueWindow"), advancedCombatLogging = A.Value("GetCVar", "advancedCombatLogging") })
    end
    if now >= nextCooldown then nextCooldown = now + 0.25; F.Combat.PollCooldowns() end
    if now >= nextPosition and A.Value("UnitAffectingCombat", "player") then
        nextPosition = now + 1
        S.Event("position", { player = A.Fields("UnitPosition", { "x", "y", "z", "instanceID" }, "player"),
            facing = A.Value("GetPlayerFacing"), speed = A.Fields("GetUnitSpeed", { "current", "run", "flight", "swim" }, "player"),
            target = F.ReadTarget("target") })
    end
end
frame:SetScript("OnUpdate", function(_, elapsed)
    local ok, message = pcall(update, elapsed)
    if not ok then F.Warn("update_error", { message = A.Clean(message) }) end
end)
