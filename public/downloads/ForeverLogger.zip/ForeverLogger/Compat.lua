local _, F = ...
local A = { capabilities = {}, failures = {}, muted = {} }
F.API = A
function A.Resolve(path)
    local value = _G
    for key in string.gmatch(path, "[^.]+") do
        if type(value) ~= "table" then return nil end
        value = value[key]
    end
    if type(value) == "function" then return value end
end
function A.Has(path)
    local exists = A.Resolve(path) ~= nil
    A.capabilities[path] = exists
    return exists
end
-- Never stringify, compare, index, or persist a secret value.
function A.Clean(value, depth, seen)
    if type(_G.issecretvalue) == "function" and _G.issecretvalue(value) then
        return nil, true
    end
    local kind = type(value)
    if kind == "nil" or kind == "boolean" or kind == "string" then return value, false end
    if kind == "number" then
        if value == value and value ~= math.huge and value ~= -math.huge then return value, false end
        return nil, true
    end
    if kind ~= "table" or (depth or 0) >= 12 then return nil, true end
    seen = seen or {}
    if seen[value] then return nil, true end
    seen[value] = true
    local out, dropped, count = {}, false, 0
    for k, v in pairs(value) do
        count = count + 1
        if count > 4096 then dropped = true; break end
        local key, badKey = A.Clean(k, 12)
        local item, badValue = A.Clean(v, (depth or 0) + 1, seen)
        if key ~= nil and not badKey then out[key] = item end
        dropped = dropped or badKey or badValue
    end
    seen[value] = nil
    return out, dropped
end
function A.Warn(code, detail)
    if F.Warn then F.Warn(code, detail) end
end
function A.Call(path, ...)
    local fn = A.Resolve(path)
    A.capabilities[path] = fn ~= nil
    if not fn then return nil, "missing" end
    local now = type(GetTime) == "function" and GetTime() or 0
    if A.muted[path] and now < A.muted[path] then return nil, "backoff" end
    local result = F.Pack(pcall(fn, ...))
    if not result[1] then
        A.failures[path] = (A.failures[path] or 0) + 1
        A.muted[path] = now + 10
        local message = A.Clean(result[2])
        A.Warn("api_error:" .. path, { message = message, retryAfterSeconds = 10 })
        return nil, "error"
    end
    local raw = { n = result.n - 1 }
    for i = 2, result.n do raw[i - 1] = result[i] end
    local ok, clean, dropped = pcall(A.Clean, raw)
    if not ok then
        A.Warn("unreadable:" .. path)
        return nil, "restricted"
    end
    if dropped then A.Warn("redacted:" .. path) end
    return clean, dropped and "partial" or "ok"
end
function A.Value(path, ...)
    local result = A.Call(path, ...)
    return result and result[1]
end
function A.First(paths)
    for _, path in ipairs(paths) do if A.Has(path) then return path end end
    return paths[1] -- records a missing capability if none exist
end
function A.Fields(path, names, ...)
    local values, status = A.Call(path, ...)
    local out = { api = path, status = status }
    if values then
        out.raw = values
        for i, name in ipairs(names) do out[name] = values[i] end
    end
    return out
end
function A.Count(path, limit, ...)
    local result = A.Value(path, ...)
    if type(result) ~= "number" or result < 0 then return 0 end
    if result > limit then A.Warn("scan_limit:" .. path, { reported = result, limit = limit }) end
    return math.min(math.floor(result), limit)
end
