local _, F = ...
local A = F.API
local C = { tracked = {}, cooldowns = {}, resources = {} }
F.Combat = C
local function cleuValues()
    return A.Call(A.First({ "CombatLogGetCurrentEventInfo", "C_CombatLog.GetCurrentEventInfo" }))
end
function C.Log(ts)
    if A.Value("C_CombatLog.IsCombatLogRestricted") then F.Warn("combat_log_restricted"); return end
    local v, status = cleuValues()
    if not v or status ~= "ok" then F.Warn("combat_log_unreadable", { status = status }); return end
    local player, pet = A.Value("UnitGUID", "player"), A.Value("UnitGUID", "pet")
    local src, dst = v[4], v[8]
    if not ((player and (src == player or dst == player)) or (pet and (src == pet or dst == pet))) then return end
    if type(v[1]) ~= "number" or type(v[2]) ~= "string" then F.Warn("combat_log_header_changed"); return end
    -- Just a join key: the native log remains the source for damage/healing payloads.
    -- Amount is retained to disambiguate identical spell/GUID events in the same batch.
    local spellID, amount
    if v[2]:match("^SPELL_") or v[2]:match("^RANGE_") then
        spellID = v[12]
        if v[2]:match("_DAMAGE$") or v[2]:match("_HEAL$") or v[2]:match("_ENERGIZE$") then amount = v[15] end
    elseif v[2] == "SWING_DAMAGE" then amount = v[12] end
    F.Storage.Event("combat_ref", { combatTimestamp = v[1], subevent = v[2], sourceGUID = src, destGUID = dst,
        spellID = spellID, amount = amount }, ts)
end
function C.Resources(unit, token, ts)
    local value = F.ReadResources(unit, token)
    local key = unit .. ":" .. (token or "")
    if not F.Equal(C.resources[key], value) then
        C.resources[key] = value
        F.Storage.Event("resources", value, ts)
    end
end
function C.Cooldown(spellID, reason, ts)
    if type(spellID) ~= "number" then return end
    local value = { spellID = spellID }
    if A.Has("C_Spell.GetSpellCooldown") then
        value.cooldown = A.Fields("C_Spell.GetSpellCooldown", { "info" }, spellID)
    else value.cooldown = A.Fields("GetSpellCooldown", { "start", "duration", "enabled", "modRate" }, spellID) end
    if A.Has("C_Spell.GetSpellCharges") then
        value.charges = A.Fields("C_Spell.GetSpellCharges", { "info" }, spellID)
    else value.charges = A.Fields("GetSpellCharges", { "current", "max", "start", "duration", "modRate" }, spellID) end
    if not F.Equal(C.cooldowns[spellID], value) then
        C.cooldowns[spellID] = value
        F.Storage.Event("cooldown", { reason = reason, observation = value }, ts)
    end
end
function C.Cast(event, args, ts)
    local unit = args[1]
    local data = { event = event, args = args, unit = unit }
    -- Classic UNIT_SPELLCAST_SENT adds a target-name field before castGUID and spellID.
    -- Discard the target name; the GUIDs below identify the currently observable target only.
    if event == "UNIT_SPELLCAST_SENT" then data.args = F.Copy(args); data.args[2] = nil end
    local spellID = event == "UNIT_SPELLCAST_SENT" and args[4] or args[3]
    data.spellID = spellID
    if type(spellID) == "number" then
        data.powerCosts = A.Fields(A.First({ "C_Spell.GetSpellPowerCost", "GetSpellPowerCost" }), { "costs" }, spellID)
    end
    data.cast = A.Fields("UnitCastingInfo", { "name", "text", "texture", "startMS", "endMS", "tradeSkill", "castID", "notInterruptible", "spellID" }, unit)
    data.channel = A.Fields("UnitChannelInfo", { "name", "text", "texture", "startMS", "endMS", "tradeSkill", "notInterruptible", "spellID" }, unit)
    data.targetGUID = A.Value("UnitGUID", "target")
    data.targetMeaning = "current_selected_target_not_guaranteed_cast_target"
    F.Storage.Event("cast", data, ts)
    if unit == "player" and type(spellID) == "number" then
        local n = 0
        for _ in pairs(C.tracked) do n = n + 1 end
        if n < 128 or C.tracked[spellID] then C.tracked[spellID] = true else F.Warn("cooldown_tracking_limit") end
        C.Cooldown(spellID, event, ts)
        C.cooldownDirty = true
    end
    C.Resources(unit, nil, ts)
end
function C.PollCooldowns()
    if not C.cooldownDirty then return end
    C.cooldownDirty = false
    for spellID in pairs(C.tracked) do C.Cooldown(spellID, "cooldown_event_coalesced") end
    local equipped = {}
    for slot = 0, 19 do
        local raw, status = A.Call("GetInventoryItemCooldown", "player", slot)
        if raw and raw[2] and raw[2] > 0 then equipped[#equipped + 1] = { slot = slot, raw = raw, status = status } end
    end
    if not F.Equal(C.itemCooldowns, equipped) then
        C.itemCooldowns = equipped
        F.Storage.Event("item_cooldowns", equipped)
    end
end
function C.Logging()
    -- A single call per interval. Even a query counts toward Blizzard's shared rate limit.
    local now = GetTime()
    if C.lastLoggingAttempt and now - C.lastLoggingAttempt < F.Storage.db.settings.loggingSeconds then return end
    C.lastLoggingAttempt = now
    local result, status = A.Call("LoggingCombat", true)
    local active = result and result[1]
    local data = { status = status, enabled = active, observed = F.Clock.Stamp() }
    if active == nil then data.status = status == "ok" and "unknown_rate_limited" or status end
    F.session.nativeLogging = data
    F.Storage.Event("native_logging", data, data.observed)
    if active ~= true then F.Warn("native_logging_unconfirmed", { status = data.status }) end
end
