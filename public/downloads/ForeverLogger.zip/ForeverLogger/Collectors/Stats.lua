local _, F = ...
local A = F.API
local definitions = {
    attackPower = { "UnitAttackPower", { "base", "positive", "negative" }, "player" },
    rangedAttackPower = { "UnitRangedAttackPower", { "base", "positive", "negative" }, "player" },
    damage = { "UnitDamage", { "min", "max", "offMin", "offMax", "positive", "negative", "multiplier" }, "player" },
    attackSpeed = { "UnitAttackSpeed", { "main", "off" }, "player" },
    rangedDamage = { "UnitRangedDamage", { "speed", "min", "max", "positive", "negative", "multiplier" }, "player" },
    armor = { "UnitArmor", { "base", "effective", "armor", "positive", "negative" }, "player" },
    defense = { "UnitDefense", { "base", "modifier" }, "player" },
    weaponSkill = { "UnitAttackBothHands", { "mainBase", "mainModifier", "offBase", "offModifier" }, "player" },
    rangedSkill = { "UnitRangedAttack", { "base", "modifier" }, "player" },
    meleeCrit = { "GetCritChance", { "percent" } }, rangedCrit = { "GetRangedCritChance", { "percent" } },
    healing = { "GetSpellBonusHealing", { "value" } },
    meleeHitModifier = { "GetHitModifier", { "percent" } },
    spellHitModifier = { "GetSpellHitModifier", { "percent" } },
    haste = { "GetHaste", { "percent" } }, meleeHaste = { "GetMeleeHaste", { "percent" } },
    rangedHaste = { "GetRangedHaste", { "percent" } }, spellHaste = { "UnitSpellHaste", { "percent" }, "player" },
    expertise = { "GetExpertise", { "main", "off" } },
    expertisePercent = { "GetExpertisePercent", { "main", "off" } },
    spellPenetration = { "GetSpellPenetration", { "value" } },
    armorPenetration = { "GetArmorPenetration", { "value" } },
    dodge = { "GetDodgeChance", { "percent" } }, parry = { "GetParryChance", { "percent" } },
    block = { "GetBlockChance", { "percent" } }, shieldBlock = { "GetShieldBlock", { "value" } },
    manaRegen = { "GetManaRegen", { "base", "casting" } },
    powerRegen = { "GetPowerRegen", { "inactive", "active" } },
    healthRegen = { "GetUnitHealthRegenRateFromSpirit", { "value" }, "player" },
    mastery = { "GetMasteryEffect", { "primary", "secondary", "tertiary" } },
    maxHealth = { "UnitHealthMax", { "value" }, "player" },
}
local statNames = { "strength", "agility", "stamina", "intellect", "spirit" }
local ratingConstants
F.Collect("stats", function()
    local out = { primary = {}, schools = {}, ratings = {}, maxPowers = {} }
    for key, d in pairs(definitions) do
        if d[3] then out[key] = A.Fields(d[1], d[2], d[3]) else out[key] = A.Fields(d[1], d[2]) end
    end
    for i, name in ipairs(statNames) do
        out.primary[name] = A.Fields("UnitStat", { "base", "effective", "positive", "negative" }, "player", i)
    end
    for school = 1, 7 do
        out.schools[school] = {
            spellPower = A.Fields("GetSpellBonusDamage", { "value" }, school),
            crit = A.Fields("GetSpellCritChance", { "percent" }, school),
            resistance = A.Fields("UnitResistance", { "base", "total", "positive", "negative" }, "player", school - 1),
        }
    end
    -- Query only client-defined rating indices; aliases remain labeled by their native constant.
    if not ratingConstants then
        ratingConstants = {}
        for key, value in pairs(_G) do
            if type(key) == "string" and key:match("^CR_") and type(value) == "number" and value >= 1 and value <= 64 then
                ratingConstants[key] = value
            end
        end
    end
    for key, value in pairs(ratingConstants) do
        out.ratings[key] = { index = value, rating = A.Value("GetCombatRating", value), bonus = A.Value("GetCombatRatingBonus", value) }
    end
    local powerTypes = { MANA = 0, RAGE = 1, FOCUS = 2, ENERGY = 3, COMBO_POINTS = 4 }
    if type(Enum) == "table" and type(Enum.PowerType) == "table" then
        for key, value in pairs(Enum.PowerType) do
            if type(value) == "number" and value >= 0 and value < 64 and key ~= "NumPowerTypes" then powerTypes[key] = value end
        end
    end
    for key, index in pairs(powerTypes) do
        out.maxPowers[key] = { index = index, value = A.Value("UnitPowerMax", "player", index) }
    end
    return out
end)
