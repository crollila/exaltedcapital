local _, F = ...
local A = F.API
local E = { tooltips = {}, queue = {}, retries = {} }
F.Equipment = E
function E.ParseLink(link)
    local text = type(link) == "string" and link:match("item:([^|]+)")
    if not text then return nil end
    local fields = {}
    for field in (text .. ":"):gmatch("(.-):") do fields[#fields + 1] = field end
    return { itemID = tonumber(fields[1]), enchantID = tonumber(fields[2]),
        gemEnchantIDs = { tonumber(fields[3]) or 0, tonumber(fields[4]) or 0, tonumber(fields[5]) or 0, tonumber(fields[6]) or 0 },
        fields = fields, raw = text }
end
function E.Invalidate()
    E.tooltips, E.queue, E.retries = {}, {}, {}
end
local function color(c)
    if type(c) == "table" then return F.Pack(c.r, c.g, c.b, c.a) end
end
local function tooltip(slot)
    -- 12.x clients: read tooltip data directly. A scanning GameTooltip frame runs Blizzard's tooltip
    -- handlers on a tainted path there, which ends in "blocked from an action only available to the Blizzard UI".
    local info = A.Resolve("C_TooltipInfo.GetInventoryItem")
    if info then
        local data = info("player", slot)
        local lines = {}
        if type(data) == "table" and type(data.lines) == "table" then
            for i = 1, math.min(#data.lines, 120) do
                local row = data.lines[i]
                lines[#lines + 1] = { left = row.leftText, right = row.rightText,
                    leftColor = color(row.leftColor), rightColor = color(row.rightColor) }
            end
        end
        return A.Clean(lines)
    end
    if not E.tip then E.tip = CreateFrame("GameTooltip", "ForeverLoggerScanTooltip", UIParent, "GameTooltipTemplate") end
    local tip = E.tip
    tip:SetOwner(UIParent, "ANCHOR_NONE")
    tip:ClearLines()
    tip:SetInventoryItem("player", slot)
    local lines = {}
    for i = 1, math.min(tip:NumLines(), 120) do
        local left, right = _G["ForeverLoggerScanTooltipTextLeft" .. i], _G["ForeverLoggerScanTooltipTextRight" .. i]
        local line = {}
        if left then line.left = left:GetText(); line.leftColor = F.Pack(left:GetTextColor()) end
        if right then line.right = right:GetText(); line.rightColor = F.Pack(right:GetTextColor()) end
        lines[#lines + 1] = line
    end
    tip:Hide()
    return A.Clean(lines)
end
function E.Pump()
    if A.Value("InCombatLockdown") or not F.session or not F.session.recording then return end
    local slot = next(E.queue)
    if not slot then return end
    E.queue[slot] = nil
    local link = A.Value("GetInventoryItemLink", "player", slot)
    if not link then return end
    local ok, lines = pcall(tooltip, slot)
    if not ok or not lines or #lines == 0 then
        E.retries[slot] = (E.retries[slot] or 0) + 1
        if E.retries[slot] < 3 then E.queue[slot] = true end
        F.Warn("tooltip_unavailable", { slot = slot })
        return
    end
    E.tooltips[slot] = { link = link, lines = lines, observed = F.Clock.Stamp() }
    -- One capture once every queued slot has its tooltip, not one per slot.
    if next(E.queue) == nil then F.State.Capture({ "equipment" }, "item_tooltips_ready") end
end
local function detectSet(lines, setID)
    -- Parse enUS/enGB evidence only; retain verbatim text/colors for every locale.
    local locale = A.Value("GetLocale")
    local out = { setID = setID, bonuses = {}, detection = "unparsed_locale" }
    if locale ~= "enUS" and locale ~= "enGB" then return out end
    out.detection = "tooltip_text_inference"
    for _, line in ipairs(lines) do
        local text = line.left or ""
        local name, worn, total = text:match("^(.-) %((%d+)/(%d+)%)$")
        if name then out.name, out.equipped, out.total = name, tonumber(worn), tonumber(total) end
        local pieces, description = text:match("^%((%d+)%) Set: (.+)$")
        if pieces then
            out.bonuses[#out.bonuses + 1] = { requiredPieces = tonumber(pieces), description = description, color = line.leftColor }
        end
    end
    for _, bonus in ipairs(out.bonuses) do
        if out.equipped then bonus.activeByPieceCount = out.equipped >= bonus.requiredPieces end
    end
    return out
end
local function itemCombatText(lines)
    local out = { source = "tooltip_text_inference", locale = A.Value("GetLocale") }
    if out.locale ~= "enUS" and out.locale ~= "enGB" then return out end
    for _, line in ipairs(lines) do
        local left, right = line.left or "", line.right or ""
        local low, high = left:match("^(%d[%d,%.]*) %- (%d[%d,%.]*) Damage$")
        if low then
            out.weaponMin = tonumber((low:gsub(",", "")))
            out.weaponMax = tonumber((high:gsub(",", "")))
        end
        local speed = right:match("Speed (%d+%.?%d*)") or left:match("Speed (%d+%.?%d*)")
        if speed then out.weaponSpeed = tonumber(speed) end
        local armor = left:match("^(%d[%d,]*) Armor$")
        if armor then out.armor = tonumber((armor:gsub(",", ""))) end
    end
    return out
end
F.Collect("equipment", function()
    local out = { slots = {}, sets = {}, coverage = "inventory_slots_0_to_19" }
    local infoPath = A.First({ "C_Item.GetItemInfo", "GetItemInfo" })
    local links, signature = {}, {}
    for slot = 0, 19 do
        links[slot] = A.Value("GetInventoryItemLink", "player", slot)
        signature[#signature + 1] = links[slot] or "empty"
    end
    signature = table.concat(signature, ";")
    if E.signature ~= signature then E.Invalidate(); E.signature = signature end
    for slot = 0, 19 do
        local link = links[slot]
        local id = A.Value("GetInventoryItemID", "player", slot)
        local row = { slot = slot, link = link, itemID = id, occupied = link ~= nil or id ~= nil }
        if row.occupied then
            row.itemString = E.ParseLink(link)
            row.broken = A.Value("GetInventoryItemBroken", "player", slot)
            row.durability = A.Fields("GetInventoryItemDurability", { "current", "max" }, slot)
            row.rune = A.Value("C_Engraving.GetRuneForEquipmentSlot", slot)
            if link then
                row.info = A.Fields(infoPath, { "name", "link", "quality", "level", "minLevel", "type", "subType", "stack", "equipLoc", "texture", "sellPrice", "classID", "subclassID", "bindType", "expansionID", "setID" }, link)
                row.itemStats = A.Fields(A.First({ "C_Item.GetItemStats", "GetItemStats" }), { "values" }, link)
                row.itemSpell = A.Fields(A.First({ "C_Item.GetItemSpell", "GetItemSpell" }), { "name", "spellID" }, link)
                row.gems = {}
                for i = 1, 4 do row.gems[i] = A.Fields(A.First({ "C_Item.GetItemGem", "GetItemGem" }), { "name", "link" }, link, i) end
                if not row.info.name then F.Warn("item_cache_pending", { itemID = id }) end
                local cached = E.tooltips[slot]
                if cached and cached.link == link then
                    row.tooltip = cached
                    row.set = detectSet(cached.lines, row.info.setID)
                    row.combatText = itemCombatText(cached.lines)
                else
                    row.tooltipStatus = "pending_out_of_combat"
                    if (E.retries[slot] or 0) < 3 then E.queue[slot] = true end
                end
                if row.info.setID and row.info.setID ~= 0 then
                    local key = tostring(row.info.setID)
                    out.sets[key] = out.sets[key] or { setID = row.info.setID, slots = {} }
                    table.insert(out.sets[key].slots, slot)
                end
            else F.Warn("equipped_link_pending", { slot = slot }) end
        end
        out.slots[#out.slots + 1] = row
    end
    return out
end)
local enchantLast = {}
F.Collect("weaponEnchants", function()
    local raw, status = A.Call("GetWeaponEnchantInfo")
    local out = { status = status, slots = {} }
    if not raw then return out end
    for i, slot in ipairs({ 16, 17, 18 }) do
        local offset = (i - 1) * 4
        if raw.n > offset then
            local row = { slot = slot, present = raw[offset + 1], charges = raw[offset + 3], enchantID = raw[offset + 4] }
            local remaining = raw[offset + 2]
            if type(remaining) == "number" and row.present then
                local expires = GetTime() + remaining / 1000
                local old = enchantLast[slot]
                -- Countdown reads are quantized by the client; don't mistake that for a refresh.
                if old and old.enchantID == row.enchantID and math.abs((old.expiresUptime or 0) - expires) < 1 then expires = old.expiresUptime end
                row.expiresUptime = expires
            end
            enchantLast[slot] = row
            out.slots[#out.slots + 1] = row
        end
    end
    return out
end)
