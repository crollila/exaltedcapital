local _, F = ...
local A = F.API
F.Collect("player", function()
    return {
        guid = A.Value("UnitGUID", "player"),
        class = A.Fields("UnitClass", { "name", "token", "id" }, "player"),
        race = A.Fields("UnitRace", { "name", "token", "id" }, "player"),
        level = A.Value("UnitLevel", "player"), sex = A.Value("UnitSex", "player"),
        faction = A.Fields("UnitFactionGroup", { "token", "name" }, "player"),
    }
end)
