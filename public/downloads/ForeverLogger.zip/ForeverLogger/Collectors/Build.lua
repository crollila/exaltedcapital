local _, F = ...
local A = F.API
local function spellBook()
    local out = { tabs = {}, spells = {}, status = "ok" }
    if not A.Has("GetNumSpellTabs") and A.Has("C_SpellBook.GetNumSpellBookSkillLines") then
        out.adapter = "C_SpellBook"
        for tab = 1, A.Count("C_SpellBook.GetNumSpellBookSkillLines", 32) do
            local line = A.Value("C_SpellBook.GetSpellBookSkillLineInfo", tab)
            out.tabs[tab] = line
            if type(line) == "table" and type(line.itemIndexOffset) == "number" and type(line.numSpellBookItems) == "number" then
                for slot = line.itemIndexOffset + 1, line.itemIndexOffset + math.min(line.numSpellBookItems, 1024) do
                    local item = A.Value("C_SpellBook.GetSpellBookItemInfo", slot, 0)
                    if type(item) == "table" then
                        out.spells[#out.spells + 1] = { slot = slot, tab = tab, type = item.itemType, spellID = item.spellID or item.actionID,
                            name = item.name, subName = item.subName, passive = item.isPassive, offSpec = item.isOffSpec }
                    end
                end
            else out.status = "partial" end
        end
        return out
    end
    if not A.Has("GetNumSpellTabs") then out.status = "unavailable"; F.Warn("spellbook_enumeration_unavailable"); return out end
    for tab = 1, A.Count("GetNumSpellTabs", 32) do
        local info = A.Fields("GetSpellTabInfo", { "name", "texture", "offset", "count", "isGuild", "offSpecID", "hidden", "specID" }, tab)
        out.tabs[tab] = info
        local offset, count = info.offset, info.count
        if type(offset) == "number" and type(count) == "number" then
            if count > 1024 then F.Warn("spellbook_scan_limit") end
            for slot = offset + 1, offset + math.min(count, 1024) do
                local entry = A.Fields("GetSpellBookItemInfo", { "type", "id" }, slot, "spell")
                local name = A.Call("GetSpellBookItemName", slot, "spell")
                entry.slot, entry.tab = slot, tab
                entry.name, entry.rank = name and name[1], name and name[2]
                entry.spellID = name and name[3] or (entry.type == "SPELL" and entry.id or nil)
                entry.link = A.Value("GetSpellLink", slot, "spell")
                entry.passive = A.Value("IsPassiveSpell", slot, "spell")
                if entry.spellID then
                    if A.Has("C_Spell.GetSpellInfo") then entry.details = A.Fields("C_Spell.GetSpellInfo", { "info" }, entry.spellID)
                    else entry.details = A.Fields("GetSpellInfo", { "name", "rank", "icon", "castTimeMS", "minRange", "maxRange", "spellID", "originalIcon" }, entry.spellID) end
                    entry.description = A.Value(A.First({ "C_Spell.GetSpellDescription", "GetSpellDescription" }), entry.spellID)
                    entry.baseCooldown = A.Fields("GetSpellBaseCooldown", { "cooldownMS", "gcdMS" }, entry.spellID)
                    entry.powerCosts = A.Value(A.First({ "C_Spell.GetSpellPowerCost", "GetSpellPowerCost" }), entry.spellID)
                    entry.overrideSpellID = A.Value(A.First({ "C_SpellBook.FindSpellOverrideByID", "FindSpellOverrideByID" }), entry.spellID)
                end
                if entry.type == "FLYOUT" then
                    entry.flyout = A.Fields("GetFlyoutInfo", { "name", "description", "count", "known" }, entry.id)
                    entry.flyout.spells = {}
                    for i = 1, math.min(entry.flyout.count or 0, 128) do
                        entry.flyout.spells[i] = A.Fields("GetFlyoutSlotInfo", { "spellID", "overrideSpellID", "known", "name", "slotSpecID" }, entry.id, i)
                    end
                end
                out.spells[#out.spells + 1] = entry
            end
        else out.status = "partial"; F.Warn("spellbook_tab_unreadable") end
    end
    return out
end
-- Forever talents are trait trees (C_Traits), not GetTalentInfo tabs.
local function traits()
    local out = { adapter = "C_Traits", trees = {}, status = "ok" }
    local config = A.Value("C_ClassTalents.GetActiveConfigID")
    local info = config and A.Value("C_Traits.GetConfigInfo", config)
    if type(info) ~= "table" or type(info.treeIDs) ~= "table" then out.status = "unavailable_or_not_ready"; return out end
    out.configID, out.configType, out.configName = config, info.type, info.name
    for _, treeID in ipairs(info.treeIDs) do
        -- talents[] mirrors nodes[] in the legacy row shape consumers already read; IDs are trait node IDs.
        local tree = { treeID = treeID, nodes = {}, talents = {}, idNamespace = "trait_node" }
        local nodes = A.Value("C_Traits.GetTreeNodes", treeID)
        for i, nodeID in ipairs(type(nodes) == "table" and nodes or {}) do
            if i > 512 then F.Warn("trait_scan_limit"); break end
            local node = A.Value("C_Traits.GetNodeInfo", config, nodeID)
            if type(node) == "table" and (node.ranksPurchased or 0) > 0 then
                local entryID = type(node.activeEntry) == "table" and node.activeEntry.entryID or nil
                local entry = entryID and A.Value("C_Traits.GetEntryInfo", config, entryID)
                local definition = type(entry) == "table" and entry.definitionID and A.Value("C_Traits.GetDefinitionInfo", entry.definitionID)
                tree.nodes[#tree.nodes + 1] = { nodeID = nodeID, entryID = entryID, ranks = node.ranksPurchased, activeRank = node.activeRank,
                    maxRanks = node.maxRanks, row = node.posY, column = node.posX,
                    definitionID = type(entry) == "table" and entry.definitionID or nil,
                    spellID = type(definition) == "table" and definition.spellID or nil }
                tree.talents[#tree.talents + 1] = { talentID = nodeID, rank = node.ranksPurchased, maxRank = node.maxRanks,
                    spellID = tree.nodes[#tree.nodes].spellID }
            end
        end
        out.trees[#out.trees + 1] = tree
    end
    return out
end
local function talents()
    if A.Has("C_ClassTalents.GetActiveConfigID") and A.Has("C_Traits.GetNodeInfo") and not A.Has("GetNumTalentTabs") then return traits() end
    local out = { trees = {}, status = "ok" }
    local modern = A.Has("C_SpecializationInfo.GetTalentInfo") and A.Has("C_SpecializationInfo.GetSpecializationInfo")
    out.adapter = modern and "classic_structured" or "classic_legacy"
    out.activeGroup = A.Value(A.First({ "C_SpecializationInfo.GetActiveSpecGroup", "GetActiveTalentGroup" }))
    local countPath = A.First({ "GetNumTalentTabs", "GetNumSpecializations" })
    local count = A.Count(countPath, 32)
    if count == 0 and modern then
        local class = A.Call("UnitClass", "player")
        if class and class[3] then count = A.Count("C_SpecializationInfo.GetNumSpecializationsForClassID", 32, class[3]) end
    end
    if count == 0 or not A.Has("GetNumTalents") then
        out.status = "unavailable_or_not_ready"; F.Warn("talent_enumeration_unavailable"); return out
    end
    for tab = 1, count do
        local tree
        if modern then
            tree = A.Fields("C_SpecializationInfo.GetSpecializationInfo", { "id", "name", "description", "icon", "role", "primaryStat", "pointsSpent", "background", "previewPointsSpent", "unlocked" }, tab, false, false, nil, nil, out.activeGroup)
        else
            local raw, status = A.Call("GetTalentTabInfo", tab)
            tree = { raw = raw, status = status, api = "GetTalentTabInfo" }
            if raw then
                if type(raw[1]) == "string" then tree.name, tree.icon, tree.pointsSpent, tree.background = raw[1], raw[2], raw[3], raw[4]
                else tree.id, tree.name, tree.pointsSpent, tree.background = raw[1], raw[2], raw[5], raw[6] end
            end
        end
        tree.index, tree.talents = tab, {}
        for i = 1, A.Count("GetNumTalents", 128, tab) do
            local talent
            if modern then
                local data, status = A.Call("C_SpecializationInfo.GetTalentInfo", { specializationIndex = tab, talentIndex = i, groupIndex = out.activeGroup, isInspect = false, isPet = false })
                talent = { info = data and data[1], status = status }
            else
                talent = A.Fields("GetTalentInfo", { "name", "icon", "tier", "column", "rank", "maxRank", "exceptional", "available" }, tab, i)
            end
            talent.index = i
            talent.link = A.Value("GetTalentLink", tab, i)
            -- talent: IDs are not spell IDs; preserve the link and its namespace.
            talent.talentID = talent.info and talent.info.talentID or (talent.link and tonumber(talent.link:match("talent:(%d+)")))
            talent.prerequisites = A.Call("GetTalentPrereqs", tab, i)
            if not talent.talentID then F.Warn("talent_id_unavailable") end
            tree.talents[i] = talent
        end
        out.trees[tab] = tree
    end
    return out
end
local function skills()
    local out = { entries = {}, includesCollapsedHeaders = false }
    if not A.Has("GetNumSkillLines") then out.status = "unavailable"; return out end
    out.status = "ok"
    for i = 1, A.Count("GetNumSkillLines", 512) do
        local entry = A.Fields("GetSkillLineInfo", { "name", "isHeader", "expanded", "rank", "temporary", "modifier", "maxRank", "abandonable", "stepCost", "rankCost", "minLevel", "maxLevel" }, i)
        out.entries[i] = entry
        if entry.isHeader and not entry.expanded then out.includesCollapsedHeaders = true end
    end
    if out.includesCollapsedHeaders then F.Warn("skills_hidden_by_collapsed_headers") end
    return out
end
F.Collect("build", function()
    return { talents = talents(), spellbook = spellBook(), skills = skills() }
end)
