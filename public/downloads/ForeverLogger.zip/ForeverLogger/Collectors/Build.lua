local _, F = ...
local A = F.API
local function spellBook()
    local out = { tabs = {}, spells = {}, status = "ok" }
    if not A.Has("GetNumSpellTabs") then out.status = "unavailable"; F.Warn("spellbook_enumeration_unavailable"); return out end
    for tab = 1, A.Count("GetNumSpellTabs", 32) do
        local info = A.Fields("GetSpellTabInfo", { "name", "texture", "offset", "count", "isGuild", "offSpecID", "hidden", "specID" }, tab)
        out.tabs[tab] = info
        local offset, count = info.offset, info.count
        if type(offset) == "number" and type(count) == "number" then
            if count > 1024 then F.Warn("spellbook_scan_limit") end
            for slot = offset + 1, offset + math.min(count, 1024) do
                local entry = A.Fields("GetSpellBookItemInfo", { "type", "id" }, slot, "spell")
                local name = A.Call("GetSpellBookItemName", slot, "spell")
                entry.slot, entry.tab = slot, tab
                entry.name, entry.rank = name and name[1], name and name[2]
                entry.spellID = name and name[3] or (entry.type == "SPELL" and entry.id or nil)
                entry.link = A.Value("GetSpellLink", slot, "spell")
                entry.passive = A.Value("IsPassiveSpell", slot, "spell")
                if entry.spellID then
                    if A.Has("C_Spell.GetSpellInfo") then entry.details = A.Fields("C_Spell.GetSpellInfo", { "info" }, entry.spellID)
                    else entry.details = A.Fields("GetSpellInfo", { "name", "rank", "icon", "castTimeMS", "minRange", "maxRange", "spellID", "originalIcon" }, entry.spellID) end
                    entry.description = A.Value(A.First({ "C_Spell.GetSpellDescription", "GetSpellDescription" }), entry.spellID)
                    entry.baseCooldown = A.Fields("GetSpellBaseCooldown", { "cooldownMS", "gcdMS" }, entry.spellID)
                    entry.powerCosts = A.Value(A.First({ "C_Spell.GetSpellPowerCost", "GetSpellPowerCost" }), entry.spellID)
                    entry.overrideSpellID = A.Value(A.First({ "C_SpellBook.FindSpellOverrideByID", "FindSpellOverrideByID" }), entry.spellID)
                end
                if entry.type == "FLYOUT" then
                    entry.flyout = A.Fields("GetFlyoutInfo", { "name", "description", "count", "known" }, entry.id)
                    entry.flyout.spells = {}
                    for i = 1, math.min(entry.flyout.count or 0, 128) do
                        entry.flyout.spells[i] = A.Fields("GetFlyoutSlotInfo", { "spellID", "overrideSpellID", "known", "name", "slotSpecID" }, entry.id, i)
                    end
                end
                out.spells[#out.spells + 1] = entry
            end
        else out.status = "partial"; F.Warn("spellbook_tab_unreadable") end
    end
    return out
end
local function talents()
    local out = { trees = {}, status = "ok" }
    local modern = A.Has("C_SpecializationInfo.GetTalentInfo") and A.Has("C_SpecializationInfo.GetSpecializationInfo")
    out.adapter = modern and "classic_structured" or "classic_legacy"
    out.activeGroup = A.Value(A.First({ "C_SpecializationInfo.GetActiveSpecGroup", "GetActiveTalentGroup" }))
    local countPath = A.First({ "GetNumTalentTabs", "GetNumSpecializations" })
    local count = A.Count(countPath, 32)
    if count == 0 and modern then
        local class = A.Call("UnitClass", "player")
        if class and class[3] then count = A.Count("C_SpecializationInfo.GetNumSpecializationsForClassID", 32, class[3]) end
    end
    if count == 0 or not A.Has("GetNumTalents") then
        out.status = "unavailable_or_not_ready"; F.Warn("talent_enumeration_unavailable"); return out
    end
    for tab = 1, count do
        local tree
        if modern then
            tree = A.Fields("C_SpecializationInfo.GetSpecializationInfo", { "id", "name", "description", "icon", "role", "primaryStat", "pointsSpent", "background", "previewPointsSpent", "unlocked" }, tab, false, false, nil, nil, out.activeGroup)
        else
            local raw, status = A.Call("GetTalentTabInfo", tab)
            tree = { raw = raw, status = status, api = "GetTalentTabInfo" }
            if raw then
                if type(raw[1]) == "string" then tree.name, tree.icon, tree.pointsSpent, tree.background = raw[1], raw[2], raw[3], raw[4]
                else tree.id, tree.name, tree.pointsSpent, tree.background = raw[1], raw[2], raw[5], raw[6] end
            end
        end
        tree.index, tree.talents = tab, {}
        for i = 1, A.Count("GetNumTalents", 128, tab) do
            local talent
            if modern then
                local data, status = A.Call("C_SpecializationInfo.GetTalentInfo", { specializationIndex = tab, talentIndex = i, groupIndex = out.activeGroup, isInspect = false, isPet = false })
                talent = { info = data and data[1], status = status }
            else
                talent = A.Fields("GetTalentInfo", { "name", "icon", "tier", "column", "rank", "maxRank", "exceptional", "available" }, tab, i)
            end
            talent.index = i
            talent.link = A.Value("GetTalentLink", tab, i)
            -- talent: IDs are not spell IDs; preserve the link and its namespace.
            talent.talentID = talent.info and talent.info.talentID or (talent.link and tonumber(talent.link:match("talent:(%d+)")))
            talent.prerequisites = A.Call("GetTalentPrereqs", tab, i)
            if not talent.talentID then F.Warn("talent_id_unavailable") end
            tree.talents[i] = talent
        end
        out.trees[tab] = tree
    end
    return out
end
local function skills()
    local out = { entries = {}, includesCollapsedHeaders = false }
    if not A.Has("GetNumSkillLines") then out.status = "unavailable"; return out end
    out.status = "ok"
    for i = 1, A.Count("GetNumSkillLines", 512) do
        local entry = A.Fields("GetSkillLineInfo", { "name", "isHeader", "expanded", "rank", "temporary", "modifier", "maxRank", "abandonable", "stepCost", "rankCost", "minLevel", "maxLevel" }, i)
        out.entries[i] = entry
        if entry.isHeader and not entry.expanded then out.includesCollapsedHeaders = true end
    end
    if out.includesCollapsedHeaders then F.Warn("skills_hidden_by_collapsed_headers") end
    return out
end
F.Collect("build", function()
    return { talents = talents(), spellbook = spellBook(), skills = skills() }
end)
