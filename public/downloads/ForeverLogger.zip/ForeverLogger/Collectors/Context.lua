local _, F = ...
local A = F.API
F.Collect("context", function()
    local forms = {}
    for i = 1, A.Count("GetNumShapeshiftForms", 32) do
        forms[i] = A.Fields("GetShapeshiftFormInfo", { "icon", "active", "castable", "spellID" }, i)
    end
    return {
        form = A.Value("GetShapeshiftForm"), formID = A.Value("GetShapeshiftFormID"), forms = forms,
        powerType = A.Fields("UnitPowerType", { "index", "token", "r", "g", "b" }, "player"),
        combat = A.Value("UnitAffectingCombat", "player"), dead = A.Value("UnitIsDeadOrGhost", "player"),
        resting = A.Value("IsResting"), mounted = A.Value("IsMounted"),
        pvp = A.Value("UnitIsPVP", "player"), pvpFFA = A.Value("UnitIsPVPFreeForAll", "player"),
        instance = A.Fields("GetInstanceInfo", { "name", "type", "difficultyID", "difficultyName", "maxPlayers", "dynamicDifficulty", "isDynamic", "instanceID", "instanceGroupSize" }),
        zone = A.Value("GetZoneText"), subzone = A.Value("GetSubZoneText"),
        mapID = A.Value("C_Map.GetBestMapForUnit", "player"),
        petGUID = A.Value("UnitGUID", "pet"),
    }
end)
F.Collect("pet", function()
    local guid = A.Value("UnitGUID", "pet")
    if not guid then return { present = false } end
    local out = { present = true, guid = guid, level = A.Value("UnitLevel", "pet"),
        family = A.Value("UnitCreatureFamily", "pet"), creatureType = A.Value("UnitCreatureType", "pet"),
        damage = A.Fields("UnitDamage", { "min", "max", "offMin", "offMax", "positive", "negative", "multiplier" }, "pet"),
        attackSpeed = A.Fields("UnitAttackSpeed", { "main", "off" }, "pet"),
        attackPower = A.Fields("UnitAttackPower", { "base", "positive", "negative" }, "pet"),
        armor = A.Fields("UnitArmor", { "base", "effective", "armor", "positive", "negative" }, "pet"),
        happiness = A.Fields("GetPetHappiness", { "happiness", "damagePercent", "loyaltyRate" }),
        auras = F.ReadAuras("pet"), spells = {},
    }
    for i = 1, A.Count(A.First({ "HasPetSpells", "C_SpellBook.HasPetSpells" }), 256) do
        out.spells[i] = A.Fields("GetSpellBookItemInfo", { "type", "spellID" }, i, "pet")
    end
    return out
end)
function F.ReadResources(unit, powerToken)
    local powerIndex
    if type(powerToken) == "string" then
        local known = { MANA = 0, RAGE = 1, FOCUS = 2, ENERGY = 3, COMBO_POINTS = 4, RUNES = 5, RUNIC_POWER = 6 }
        powerIndex = _G["SPELL_POWER_" .. powerToken] or known[powerToken]
    end
    return {
        unit = unit, guid = A.Value("UnitGUID", unit), powerToken = powerToken,
        health = A.Value("UnitHealth", unit), maxHealth = A.Value("UnitHealthMax", unit),
        powerType = A.Fields("UnitPowerType", { "index", "token" }, unit),
        power = A.Value("UnitPower", unit), powerRaw = A.Value("UnitPower", unit, nil, true),
        maxPower = A.Value("UnitPowerMax", unit), mana = A.Value("UnitPower", unit, 0),
        changedPowerIndex = powerIndex, changedPower = powerIndex and A.Value("UnitPower", unit, powerIndex),
        comboPoints = unit == "player" and A.Value("GetComboPoints", "player", "target") or nil,
    }
end
function F.ReadTarget(unit)
    return { unit = unit, guid = A.Value("UnitGUID", unit), level = A.Value("UnitLevel", unit),
        classification = A.Value("UnitClassification", unit), creatureType = A.Value("UnitCreatureType", unit),
        creatureFamily = A.Value("UnitCreatureFamily", unit),
        health = A.Value("UnitHealth", unit), maxHealth = A.Value("UnitHealthMax", unit),
        attackable = A.Value("UnitCanAttack", "player", unit),
        position = A.Fields("UnitPosition", { "x", "y", "z", "instanceID" }, unit) }
end
