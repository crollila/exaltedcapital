local _, F = ...
local A = F.API
-- 12.x aura readers take a "UnitTokenRestrictedForAddOns" and their access check fails with a blocked-action
-- error (client docs: RequiresUnitAuraAccess, FailureMode = Error), not a nil return. Nameplate and other
-- unit tokens are not readable by addons there; keep to the tokens Blizzard's own non-secure UI uses.
local readable = { player = true, pet = true, target = true, focus = true, targettarget = true, focustarget = true, mouseover = true, vehicle = true }
for i = 1, 4 do readable["party" .. i] = true; readable["partypet" .. i] = true end
for i = 1, 40 do readable["raid" .. i] = true; readable["raidpet" .. i] = true end
for i = 1, 5 do readable["boss" .. i] = true; readable["arena" .. i] = true end
F.ReadAuras = function(unit)
    local out = { helpful = {}, harmful = {}, status = "ok" }
    local modern = A.Has("C_UnitAuras.GetAuraDataByIndex")
    if modern and not readable[unit] then
        out.status = "restricted_unit_token"; return out
    end
    if not modern and not A.Has("UnitAura") then
        out.status = "unavailable"; F.Warn("auras_unavailable"); return out
    end
    out.adapter = modern and "C_UnitAuras.GetAuraDataByIndex" or "UnitAura"
    for _, filter in ipairs({ "HELPFUL", "HARMFUL" }) do
        local dest = filter == "HELPFUL" and out.helpful or out.harmful
        for index = 1, 512 do
            local aura, status
            if modern then
                local raw
                raw, status = A.Call(out.adapter, unit, index, filter)
                aura = raw and raw[1]
            else
                local raw
                raw, status = A.Call("UnitAura", unit, index, filter)
                if raw and raw[1] then
                    aura = { name = raw[1], icon = raw[2], applications = raw[3], dispelName = raw[4], duration = raw[5],
                        expirationTime = raw[6], sourceUnit = raw[7], isStealable = raw[8], nameplateShowPersonal = raw[9],
                        spellId = raw[10], canApplyAura = raw[11], isBossAura = raw[12], isFromPlayerOrPlayerPet = raw[13],
                        nameplateShowAll = raw[14], timeMod = raw[15], values = { n = math.max(0, raw.n - 15) } }
                    for i = 16, raw.n do aura.values[i - 15] = raw[i] end
                end
            end
            if status ~= "ok" then out.status = status or "partial" end
            if not aura then break end
            aura.sourceGUID = aura.sourceUnit and A.Value("UnitGUID", aura.sourceUnit)
            dest[#dest + 1] = aura
            if index == 512 then out.status = "truncated"; F.Warn("aura_scan_limit") end
        end
    end
    return out
end
F.Collect("auras", function() return F.ReadAuras("player") end)
